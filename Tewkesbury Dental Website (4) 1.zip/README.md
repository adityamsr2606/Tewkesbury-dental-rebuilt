
  # Tewkesbury Dental Website

  This is a code bundle for Tewkesbury Dental Website. The original project is available at https://www.figma.com/design/zrLwMXD4G3PweCi56nZ5k9/Tewkesbury-Dental-Website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  