export const treatments = [
  {
    id: 'general-dentistry',
    title: 'General Dentistry',
    description: 'Comprehensive dental care for maintaining optimal oral health.',
    image: 'https://images.unsplash.com/photo-1642844819197-5f5f21b89ff8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkZW50YWwlMjBjbGluaWMlMjBtb2Rlcm58ZW58MXx8fHwxNzU2Mjc5MTgyfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    duration: '30-60 mins',
    price: 'From £65',
    services: [
      'Dental Examinations',
      'Professional Cleaning',
      'Digital X-Rays',
      'Fluoride Treatments',
      'Oral Health Advice'
    ]
  },
  {
    id: 'tooth-whitening',
    title: 'Tooth Whitening',
    description: 'Professional teeth whitening for a brighter, more confident smile.',
    image: 'https://images.unsplash.com/photo-1675526607070-f5cbd71dde92?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0b290aCUyMHdoaXRlbmluZyUyMHNtaWxlfGVufDF8fHx8MTc1NjI4NzU5NHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    duration: '60-90 mins',
    price: 'From £250',
    services: [
      'In-Office Whitening',
      'Custom Take-Home Trays',
      'Combination Treatments',
      'Touch-Up Sessions',
      'Maintenance Advice'
    ]
  },
  {
    id: 'dental-veneers',
    title: 'Dental Veneers',
    description: 'Transform your smile with custom porcelain veneers.',
    image: 'https://images.unsplash.com/photo-1593022356269-609ed284b3c3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkZW50YWwlMjBoeWdpZW5lJTIwdGVldGh8ZW58MXx8fHwxNzU2Mjg3NTk0fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    duration: '2-3 visits',
    price: 'From £850',
    services: [
      'Porcelain Veneers',
      'Composite Veneers',
      'Smile Design',
      'Color Matching',
      'Temporary Veneers'
    ]
  },
  {
    id: 'dental-crowns',
    title: 'Dental Crowns',
    description: 'Restore damaged teeth with high-quality dental crowns.',
    image: 'https://images.unsplash.com/photo-1704455306925-1401c3012117?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkZW50YWwlMjB0cmVhdG1lbnQlMjBjaGFpcnxlbnwxfHx8fDE3NTYyODc1OTJ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    duration: '2-3 visits',
    price: 'From £650',
    services: [
      'Porcelain Crowns',
      'Gold Crowns',
      'Same-Day Crowns',
      'Crown Lengthening',
      'Temporary Crowns'
    ]
  },
  {
    id: 'dental-bridges',
    title: 'Dental Bridges',
    description: 'Replace missing teeth with fixed dental bridges.',
    image: 'https://images.unsplash.com/photo-1642844819197-5f5f21b89ff8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkZW50YWwlMjBjbGluaWMlMjBtb2Rlcm58ZW58MXx8fHwxNzU2Mjc5MTgyfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    duration: '2-3 visits',
    price: 'From £1200',
    services: [
      'Traditional Bridges',
      'Cantilever Bridges',
      'Maryland Bridges',
      'Implant-Supported Bridges',
      'Bridge Maintenance'
    ]
  },
  {
    id: 'dental-implants',
    title: 'Dental Implants',
    description: 'Permanent solution for missing teeth with titanium implants.',
    image: 'https://images.unsplash.com/photo-1683520701490-7172fa20c8f1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkZW50YWwlMjB0ZWFtJTIwcHJvZmVzc2lvbmFsc3xlbnwxfHx8fDE3NTYxOTc2Mjd8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    duration: '3-6 months',
    price: 'From £2200',
    services: [
      'Single Implants',
      'Multiple Implants',
      'All-on-4 Treatment',
      'Bone Grafting',
      'Implant Maintenance'
    ]
  },
  {
    id: 'root-canal',
    title: 'Root Canal Treatment',
    description: 'Save infected teeth with gentle endodontic treatment.',
    image: 'https://images.unsplash.com/photo-1704455306925-1401c3012117?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkZW50YWwlMjB0cmVhdG1lbnQlMjBjaGFpcnxlbnwxfHx8fDE3NTYyODc1OTJ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    duration: '60-90 mins',
    price: 'From £450',
    services: [
      'Root Canal Therapy',
      'Pulp Treatment',
      'Post and Core',
      'Retreatment',
      'Follow-up Care'
    ]
  },
  {
    id: 'tooth-extraction',
    title: 'Tooth Extraction',
    description: 'Safe and comfortable tooth removal when necessary.',
    image: 'https://images.unsplash.com/photo-1642844819197-5f5f21b89ff8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHhkZW50YWwlMjBjbGluaWMlMjBtb2Rlcm58ZW58MXx8fHwxNzU2Mjc5MTgyfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    duration: '30-60 mins',
    price: 'From £150',
    services: [
      'Simple Extractions',
      'Surgical Extractions',
      'Wisdom Tooth Removal',
      'Socket Preservation',
      'Post-Extraction Care'
    ]
  }
];

export const features = [
  {
    icon: 'Award',
    title: 'Expert Care',
    description: 'Our experienced dental team uses the latest techniques and technology.'
  },
  {
    icon: 'Shield',
    title: 'Safe & Sterile',
    description: 'Strict infection control protocols ensure your safety and peace of mind.'
  },
  {
    icon: 'Clock',
    title: 'Flexible Appointments',
    description: 'Convenient scheduling options including evening and weekend slots.'
  }
];