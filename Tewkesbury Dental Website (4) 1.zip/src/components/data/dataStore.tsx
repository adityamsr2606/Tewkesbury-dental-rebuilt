import { create } from 'zustand';

// User types and interfaces
export interface Doctor {
  id: string;
  name: string;
  position: string;
  qualifications: string;
  bio: string;
  image: string;
  specializations: string[];
  yearsOfExperience: number;
  email: string;
  phone: string;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface Patient {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  dateOfBirth: string;
  address: string;
  emergencyContact: string;
  medicalHistory: string;
  allergies: string;
  currentMedications: string;
  insuranceProvider: string;
  insuranceNumber: string;
  registrationDate: string;
  lastVisit: string;
  nextAppointment: string;
  status: 'active' | 'inactive';
}

export interface Booking {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  preferredDate: string;
  preferredTime: string;
  treatmentType: string;
  urgency: 'routine' | 'urgent' | 'emergency';
  status: 'pending' | 'confirmed' | 'completed' | 'cancelled';
  paymentStatus: 'pending' | 'paid' | 'refunded';
  message: string;
  createdAt: string;
  doctorAssigned?: string;
  bookingType?: 'appointment' | 'membership' | 'consultation';
}

export interface Treatment {
  id: string;
  title: string;
  description: string;
  image: string;
  duration: string;
  price: string;
  services: string[];
  category: string;
  isActive: boolean;
}

export interface Review {
  id: string;
  patientName: string;
  email: string;
  phone: string;
  treatmentReceived: string;
  rating: number;
  reviewText: string;
  date: string;
  isPublic: boolean;
}

export interface BlogPost {
  id: string;
  title: string;
  excerpt: string;
  content: string;
  fullContent: string;
  author: string;
  date: string;
  category: string;
  readTime: string;
  image: string;
  isPublished: boolean;
  tags: string[];
}

export interface Staff {
  id: string;
  username: string;
  email: string;
  firstName: string;
  lastName: string;
  role: 'admin' | 'staff' | 'doctor';
  permissions: string[];
  isActive: boolean;
  lastLogin: string;
  createdAt: string;
}

export interface PracticeInfo {
  id: string;
  name: string;
  address: string;
  phone: string;
  email: string;
  openingHours: {
    [key: string]: { open: string; close: string; closed?: boolean };
  };
  aboutText: string;
  mission: string;
  vision: string;
  values: string[];
}

// Zustand store
interface DataStore {
  // Data
  doctors: Doctor[];
  patients: Patient[];
  bookings: Booking[];
  treatments: Treatment[];
  reviews: Review[];
  blogPosts: BlogPost[];
  staff: Staff[];
  practiceInfo: PracticeInfo;
  
  // Doctor actions
  addDoctor: (doctor: Omit<Doctor, 'id' | 'createdAt' | 'updatedAt'>) => void;
  updateDoctor: (id: string, updates: Partial<Doctor>) => void;
  deleteDoctor: (id: string) => void;
  
  // Patient actions
  addPatient: (patient: Omit<Patient, 'id' | 'registrationDate'>) => void;
  updatePatient: (id: string, updates: Partial<Patient>) => void;
  deletePatient: (id: string) => void;
  
  // Booking actions
  addBooking: (booking: Omit<Booking, 'id' | 'createdAt'>) => void;
  updateBooking: (id: string, updates: Partial<Booking>) => void;
  deleteBooking: (id: string) => void;
  
  // Treatment actions
  addTreatment: (treatment: Omit<Treatment, 'id'>) => void;
  updateTreatment: (id: string, updates: Partial<Treatment>) => void;
  deleteTreatment: (id: string) => void;
  
  // Review actions
  addReview: (review: Omit<Review, 'id'>) => void;
  updateReview: (id: string, updates: Partial<Review>) => void;
  deleteReview: (id: string) => void;
  
  // Blog actions
  addBlogPost: (post: Omit<BlogPost, 'id'>) => void;
  updateBlogPost: (id: string, updates: Partial<BlogPost>) => void;
  deleteBlogPost: (id: string) => void;
  
  // Staff actions
  addStaff: (staff: Omit<Staff, 'id' | 'createdAt'>) => void;
  updateStaff: (id: string, updates: Partial<Staff>) => void;
  deleteStaff: (id: string) => void;
  
  // Practice info actions
  updatePracticeInfo: (updates: Partial<PracticeInfo>) => void;
  
  // Helper functions
  findPatientByPhone: (phone: string) => Patient | undefined;
  findPatientByEmail: (email: string) => Patient | undefined;
  getAvailableDoctorsForTreatment: (treatmentCategory: string) => Doctor[];
  getTreatmentsByCategory: (category: string) => Treatment[];
}

export const useDataStore = create<DataStore>((set, get) => ({
  // Initial data
  doctors: [
    {
      id: '1',
      name: 'Dr. Sarah Mitchell',
      position: 'Principal Dentist & Practice Owner',
      qualifications: 'BDS (Hons), MFDS RCS (Ed)',
      bio: 'Dr. Mitchell has been practicing dentistry for over 15 years and established Tewkesbury Dental Practice in 2010. She specializes in cosmetic dentistry and dental implants.',
      image: 'https://images.unsplash.com/photo-1683520701490-7172fa20c8f1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHhkZW50YWwlMjB0ZWFtJTIwcHJvZmVzc2lvbmFsc3xlbnwxfHx8fDE3NTYxOTc2Mjd8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      specializations: ['Cosmetic Dentistry', 'Dental Implants', 'Veneers', 'General Dentistry'],
      yearsOfExperience: 15,
      email: 's.mitchell@tewkesburydental.co.uk',
      phone: '01684 295727',
      isActive: true,
      createdAt: '2010-01-01T00:00:00Z',
      updatedAt: '2024-01-01T00:00:00Z'
    },
    {
      id: '2',
      name: 'Dr. James Thompson',
      position: 'Associate Dentist',
      qualifications: 'BDS, MSc (Endodontics)',
      bio: 'Dr. Thompson is an expert in root canal treatments and endodontics. He joined our practice in 2018 and brings extensive experience in complex dental procedures.',
      image: 'https://images.unsplash.com/photo-1683520701490-7172fa20c8f1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHhkZW50YWwlMjB0ZWFtJTIwcHJvZmVzc2lvbmFsc3xlbnwxfHx8fDE3NTYxOTc2Mjd8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      specializations: ['Endodontics', 'Root Canal Treatment', 'Restorative Dentistry', 'General Dentistry', 'Oral Surgery'],
      yearsOfExperience: 12,
      email: 'j.thompson@tewkesburydental.co.uk',
      phone: '01684 295727',
      isActive: true,
      createdAt: '2018-03-01T00:00:00Z',
      updatedAt: '2024-01-01T00:00:00Z'
    }
  ],
  
  patients: [
    {
      id: '1',
      firstName: 'John',
      lastName: 'Smith',
      email: 'john.smith@email.com',
      phone: '1234567890',
      dateOfBirth: '1985-06-15',
      address: '123 Main Street, Tewkesbury, GL20 5AB',
      emergencyContact: 'Jane Smith - 0987654321',
      medicalHistory: 'No significant medical history',
      allergies: 'None known',
      currentMedications: 'None',
      insuranceProvider: 'Bupa',
      insuranceNumber: 'BU123456789',
      registrationDate: '2024-01-10T09:00:00Z',
      lastVisit: '2024-01-10',
      nextAppointment: '2024-01-15',
      status: 'active'
    }
  ],

  bookings: [
    {
      id: '1',
      firstName: 'John',
      lastName: 'Smith',
      email: 'john.smith@email.com',
      phone: '1234567890',
      preferredDate: '2024-01-15',
      preferredTime: '10:00 AM',
      treatmentType: 'General Checkup',
      urgency: 'routine',
      status: 'confirmed',
      paymentStatus: 'pending',
      message: 'First visit to the practice',
      createdAt: '2024-01-10T09:00:00Z',
      doctorAssigned: 'Dr. Sarah Mitchell',
      bookingType: 'appointment'
    }
  ],

  treatments: [
    // General Dentistry
    {
      id: '1',
      title: 'Dental Examination',
      description: 'Comprehensive dental checkup including visual examination, X-rays if needed, and treatment planning.',
      image: 'https://images.unsplash.com/photo-1565090567208-c8038cfcf6cd?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHhkZW50YWwlMjBleGFtaW5hdGlvbiUyMGNoZWNrdXB8ZW58MXx8fHwxNzU2MzcwMzQyfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      duration: '30 minutes',
      price: '£65',
      services: ['Visual examination', 'Oral health assessment', 'Treatment planning', 'Preventive advice'],
      category: 'General Dentistry',
      isActive: true
    },
    {
      id: '2',
      title: 'Scale and Polish',
      description: 'Professional teeth cleaning to remove plaque, tartar, and surface stains for healthier gums and brighter teeth.',
      image: 'https://images.unsplash.com/photo-1581585004042-bca38021ce1e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0ZWV0aCUyMGNsZWFuaW5nJTIwZGVudGFsJTIwaHlnaWVuZXxlbnwxfHx8fDE3NTYzNzAzNDh8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      duration: '45 minutes',
      price: '£85',
      services: ['Plaque removal', 'Tartar removal', 'Teeth polishing', 'Gum health check'],
      category: 'General Dentistry',
      isActive: true
    },
    {
      id: '3',
      title: 'Dental X-Rays',
      description: 'Digital radiographs for accurate diagnosis and treatment planning.',
      image: 'https://images.unsplash.com/photo-1729870992116-5f1f59feb4ae?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHhkZW50YWwlMjB4cmF5JTIwcmFkaW9ncmFwaHxlbnwxfHx8fDE3NTYzNzAzNTJ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      duration: '15 minutes',
      price: '£35',
      services: ['Digital X-ray imaging', 'Diagnostic consultation', 'Image analysis'],
      category: 'General Dentistry',
      isActive: true
    },
    // Cosmetic Dentistry
    {
      id: '4',
      title: 'Teeth Whitening',
      description: 'Professional teeth whitening treatment for a brighter, more confident smile.',
      image: 'https://images.unsplash.com/photo-1655807946138-811bb2340d34?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0ZWV0aCUyMHdoaXRlbmluZyUyMGRlbnRhbHxlbnwxfHx8fDE3NTYzMDI3ODl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      duration: '60 minutes',
      price: '£350',
      services: ['Professional whitening', 'Custom trays', 'Take-home kit', 'Follow-up consultation'],
      category: 'Cosmetic Dentistry',
      isActive: true
    },
    {
      id: '5',
      title: 'Porcelain Veneers',
      description: 'Custom-made porcelain veneers to transform your smile with natural-looking results.',
      image: 'https://images.unsplash.com/photo-1562330743-fbc6ef07ca78?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHhkZW50YWwlMjB2ZW5lZXJzJTIwcG9yY2VsYWlufGVufDF8fHx8MTc1NjM3MDM2Mnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      duration: '2 hours per session',
      price: '£850',
      services: ['Consultation and planning', 'Tooth preparation', 'Custom veneer creation', 'Fitting and adjustment'],
      category: 'Cosmetic Dentistry',
      isActive: true
    },
    // Restorative Dentistry
    {
      id: '6',
      title: 'White Fillings',
      description: 'Tooth-colored composite fillings that blend naturally with your teeth.',
      image: 'https://images.unsplash.com/photo-1598256989809-394fa4f6cd26?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHhkZW50YWwlMjBmaWxsaW5nJTIwdG9vdGglMjByZXN0b3JhdGlvbnxlbnwxfHx8fDE3NTYzNzAzNzB8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      duration: '45 minutes',
      price: '£120',
      services: ['Cavity removal', 'Composite filling', 'Color matching', 'Final polishing'],
      category: 'Restorative Dentistry',
      isActive: true
    },
    {
      id: '7',
      title: 'Dental Crowns',
      description: 'Protective caps that restore the shape, size, and strength of damaged teeth.',
      image: 'https://images.unsplash.com/photo-1661701422699-6550bfe60998?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHhkZW50YWwlMjBjcm93biUyMHJlc3RvcmF0aW9ufGVufDF8fHx8MTc1NjMwMTkxMnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      duration: '2 appointments',
      price: '£650',
      services: ['Tooth preparation', 'Impression taking', 'Temporary crown', 'Final crown fitting'],
      category: 'Restorative Dentistry',
      isActive: true
    },
    // Oral Surgery
    {
      id: '8',
      title: 'Tooth Extraction',
      description: 'Safe and comfortable tooth removal with proper aftercare.',
      image: 'https://images.unsplash.com/photo-1663182106210-2d372c45ed23?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0b290aCUyMGV4dHJhY3Rpb24lMjBkZW50YWwlMjBzdXJnZXJ5fGVufDF8fHx8MTc1NjM3MDM3OHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      duration: '30-60 minutes',
      price: '£150',
      services: ['Local anesthesia', 'Gentle extraction', 'Post-operative care', 'Pain management'],
      category: 'Oral Surgery',
      isActive: true
    },
    {
      id: '9',
      title: 'Dental Implants',
      description: 'Permanent tooth replacement solution with titanium implants.',
      image: 'https://images.unsplash.com/photo-1643216503879-b2c604ce6cf2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHhkZW50YWwlMjBpbXBsYW50JTIwc3VyZ2VyeXxlbnwxfHx8fDE3NTYzMDI3ODV8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      duration: 'Multiple appointments',
      price: '£2200',
      services: ['Implant placement', 'Healing period', 'Crown attachment', 'Follow-up care'],
      category: 'Oral Surgery',
      isActive: true
    }
  ],

  reviews: [
    {
      id: '1',
      patientName: 'Sarah Williams',
      email: 'sarah.williams@email.com',
      phone: '3456789012',
      treatmentReceived: 'Teeth Whitening',
      rating: 5,
      reviewText: 'Amazing results! The staff was professional and the treatment was comfortable. My teeth are now several shades whiter and I feel so much more confident about my smile. Highly recommend!',
      date: '2024-01-12T00:00:00Z',
      isPublic: true
    },
    {
      id: '2',
      patientName: 'Michael Brown',
      email: 'michael.brown@email.com',
      phone: '4567890123',
      treatmentReceived: 'Dental Examination',
      rating: 5,
      reviewText: 'Excellent service from start to finish. Dr. Mitchell was very thorough in her examination and explained everything clearly. The practice is modern and clean. Will definitely be back for regular checkups.',
      date: '2024-01-14T00:00:00Z',
      isPublic: true
    },
    {
      id: '3',
      patientName: 'Emma Thompson',
      email: 'emma.thompson@email.com',
      phone: '5678901234',
      treatmentReceived: 'Scale and Polish',
      rating: 4,
      reviewText: 'Great experience! The hygienist was gentle and professional. My teeth feel so clean and fresh. The only minor issue was the waiting time, but the quality of service made up for it.',
      date: '2024-01-16T00:00:00Z',
      isPublic: true
    }
  ],

  blogPosts: [
    {
      id: '1',
      title: 'The Complete Guide to Dental Hygiene: Tips for a Healthier Smile',
      excerpt: 'Discover essential dental hygiene practices that will keep your teeth and gums healthy for life.',
      content: 'Good dental hygiene is the foundation of oral health. Regular brushing, flossing, and professional cleanings can prevent most dental problems.',
      fullContent: `# The Complete Guide to Dental Hygiene: Tips for a Healthier Smile

Maintaining excellent dental hygiene is crucial for your overall health and well-being. Poor oral health has been linked to various systemic conditions, including heart disease, diabetes, and respiratory infections. Here's your comprehensive guide to achieving and maintaining optimal dental hygiene.

## Daily Oral Care Routine

### Brushing Technique
- Use a soft-bristled toothbrush
- Brush for at least 2 minutes, twice daily
- Use fluoride toothpaste
- Replace your toothbrush every 3-4 months
- Use gentle, circular motions
- Don't forget to brush your tongue

### Flossing Best Practices
- Floss daily, preferably before bedtime
- Use about 18 inches of floss
- Gently guide the floss between teeth
- Curve the floss around each tooth
- Use clean sections of floss for each tooth

### Mouthwash Benefits
- Choose an antimicrobial mouthwash
- Use after brushing and flossing
- Swish for 30-60 seconds
- Don't rinse with water immediately after

## Professional Dental Care

Regular dental visits are essential for maintaining oral health. Professional cleanings remove plaque and tartar that cannot be eliminated through home care alone.

### Recommended Schedule
- Dental checkups every 6 months
- Professional cleanings as recommended
- X-rays annually or as needed
- Immediate attention for dental problems

## Diet and Oral Health

What you eat significantly impacts your dental health:

### Foods to Embrace
- Dairy products (calcium and phosphorus)
- Leafy greens (vitamins and minerals)
- Lean proteins (phosphorus)
- Fruits and vegetables (fiber and water)
- Green tea (antioxidants)

### Foods to Limit
- Sugary snacks and beverages
- Acidic foods and drinks
- Sticky candies
- Hard candies that can chip teeth
- Excessive coffee and wine

## Common Dental Problems and Prevention

### Tooth Decay
- Caused by bacteria producing acid
- Prevention: proper hygiene, fluoride, limited sugar
- Early detection prevents severe damage

### Gum Disease
- Begins with gingivitis
- Can progress to periodontitis
- Prevention: regular flossing and professional cleanings

### Bad Breath
- Often caused by bacteria buildup
- Can indicate underlying dental issues
- Managed through proper oral hygiene

## Conclusion

Consistent dental hygiene practices, combined with regular professional care, will keep your smile healthy and beautiful. Remember that prevention is always better than treatment, making daily oral care an investment in your long-term health and confidence.`,
      author: 'Dr. Sarah Mitchell',
      date: '2024-01-15',
      category: 'Oral Health',
      readTime: '8 min read',
      image: 'https://images.unsplash.com/photo-1581585004042-bca38021ce1e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0ZWV0aCUyMGNsZWFuaW5nJTIwZGVudGFsJTIwaHlnaWVuZXxlbnwxfHx8fDE3NTYzNzAzNDh8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      isPublished: true,
      tags: ['oral health', 'prevention', 'hygiene', 'dental care']
    }
  ],
  
  staff: [
    {
      id: '1',
      username: 'admin',
      email: 'admin@tewkesburydental.co.uk',
      firstName: 'Admin',
      lastName: 'User',
      role: 'admin',
      permissions: ['all'],
      isActive: true,
      lastLogin: '2024-01-01T00:00:00Z',
      createdAt: '2024-01-01T00:00:00Z'
    }
  ],
  
  practiceInfo: {
    id: '1',
    name: 'Tewkesbury Dental Practice',
    address: '123 High Street, Tewkesbury, GL20 5AL',
    phone: '01684 295727',
    email: 'info@tewkesburydental.co.uk',
    openingHours: {
      monday: { open: '08:30', close: '17:30' },
      tuesday: { open: '08:30', close: '17:30' },
      wednesday: { open: '08:30', close: '17:30' },
      thursday: { open: '08:30', close: '17:30' },
      friday: { open: '08:30', close: '17:30' },
      saturday: { open: '09:00', close: '13:00' },
      sunday: { open: '00:00', close: '00:00', closed: true }
    },
    aboutText: 'Providing exceptional dental care to the Tewkesbury community for over three decades.',
    mission: 'To provide the highest quality dental care in a comfortable and caring environment.',
    vision: 'To be the leading dental practice in Tewkesbury, known for excellence and innovation.',
    values: ['Excellence', 'Compassion', 'Innovation', 'Integrity']
  },

  // Doctor actions
  addDoctor: (doctor) => set((state) => ({
    doctors: [...state.doctors, {
      ...doctor,
      id: Date.now().toString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    }]
  })),
  
  updateDoctor: (id, updates) => set((state) => ({
    doctors: state.doctors.map(doctor => 
      doctor.id === id 
        ? { ...doctor, ...updates, updatedAt: new Date().toISOString() }
        : doctor
    )
  })),
  
  deleteDoctor: (id) => set((state) => ({
    doctors: state.doctors.filter(doctor => doctor.id !== id)
  })),
  
  // Patient actions
  addPatient: (patient) => set((state) => ({
    patients: [...state.patients, {
      ...patient,
      id: Date.now().toString(),
      registrationDate: new Date().toISOString()
    }]
  })),
  
  updatePatient: (id, updates) => set((state) => ({
    patients: state.patients.map(patient => 
      patient.id === id ? { ...patient, ...updates } : patient
    )
  })),
  
  deletePatient: (id) => set((state) => ({
    patients: state.patients.filter(patient => patient.id !== id)
  })),
  
  // Booking actions
  addBooking: (booking) => set((state) => ({
    bookings: [...state.bookings, {
      ...booking,
      id: Date.now().toString(),
      createdAt: new Date().toISOString()
    }]
  })),
  
  updateBooking: (id, updates) => set((state) => ({
    bookings: state.bookings.map(booking => 
      booking.id === id ? { ...booking, ...updates } : booking
    )
  })),
  
  deleteBooking: (id) => set((state) => ({
    bookings: state.bookings.filter(booking => booking.id !== id)
  })),
  
  // Treatment actions
  addTreatment: (treatment) => set((state) => ({
    treatments: [...state.treatments, {
      ...treatment,
      id: Date.now().toString()
    }]
  })),
  
  updateTreatment: (id, updates) => set((state) => ({
    treatments: state.treatments.map(treatment => 
      treatment.id === id ? { ...treatment, ...updates } : treatment
    )
  })),
  
  deleteTreatment: (id) => set((state) => ({
    treatments: state.treatments.filter(treatment => treatment.id !== id)
  })),
  
  // Review actions
  addReview: (review) => set((state) => ({
    reviews: [...state.reviews, {
      ...review,
      id: Date.now().toString()
    }]
  })),
  
  updateReview: (id, updates) => set((state) => ({
    reviews: state.reviews.map(review => 
      review.id === id ? { ...review, ...updates } : review
    )
  })),
  
  deleteReview: (id) => set((state) => ({
    reviews: state.reviews.filter(review => review.id !== id)
  })),
  
  // Blog actions
  addBlogPost: (post) => set((state) => ({
    blogPosts: [...state.blogPosts, {
      ...post,
      id: Date.now().toString()
    }]
  })),
  
  updateBlogPost: (id, updates) => set((state) => ({
    blogPosts: state.blogPosts.map(post => 
      post.id === id ? { ...post, ...updates } : post
    )
  })),
  
  deleteBlogPost: (id) => set((state) => ({
    blogPosts: state.blogPosts.filter(post => post.id !== id)
  })),
  
  // Staff actions
  addStaff: (staff) => set((state) => ({
    staff: [...state.staff, {
      ...staff,
      id: Date.now().toString(),
      createdAt: new Date().toISOString()
    }]
  })),
  
  updateStaff: (id, updates) => set((state) => ({
    staff: state.staff.map(staff => 
      staff.id === id ? { ...staff, ...updates } : staff
    )
  })),
  
  deleteStaff: (id) => set((state) => ({
    staff: state.staff.filter(staff => staff.id !== id)
  })),
  
  // Practice info actions
  updatePracticeInfo: (updates) => set((state) => ({
    practiceInfo: { ...state.practiceInfo, ...updates }
  })),
  
  // Helper functions
  findPatientByPhone: (phone: string) => {
    const state = get();
    return state.patients.find(patient => patient.phone === phone);
  },
  
  findPatientByEmail: (email: string) => {
    const state = get();
    return state.patients.find(patient => patient.email === email);
  },
  
  getAvailableDoctorsForTreatment: (treatmentCategory: string) => {
    const state = get();
    return state.doctors.filter(doctor => 
      doctor.isActive && 
      doctor.specializations.some(spec => 
        spec.toLowerCase().includes(treatmentCategory.toLowerCase()) || 
        treatmentCategory.toLowerCase().includes(spec.toLowerCase()) ||
        spec === 'General Dentistry'
      )
    );
  },
  
  getTreatmentsByCategory: (category: string) => {
    const state = get();
    return state.treatments.filter(treatment => 
      treatment.isActive && treatment.category === category
    );
  }
}));