import React from 'react';
import { Link } from 'react-router-dom';
import { Star, Quote, Calendar, User, Award } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { useDataStore } from './data/dataStore';

const TestimonialsPage = () => {
  const { reviews } = useDataStore();
  
  // Filter public reviews
  const publicReviews = reviews.filter(review => review.isPublic);

  // Calculate average rating
  const averageRating = publicReviews.length > 0 
    ? publicReviews.reduce((sum, review) => sum + review.rating, 0) / publicReviews.length
    : 0;

  const renderStars = (rating) => {
    return [...Array(5)].map((_, i) => (
      <Star 
        key={i} 
        className={`h-5 w-5 ${i < rating ? 'text-yellow-500 fill-current' : 'text-gray-300'}`} 
      />
    ));
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-r from-blue-600 to-teal-600 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl lg:text-6xl mb-6">Patient Testimonials</h1>
            <p className="text-xl lg:text-2xl text-blue-100 max-w-3xl mx-auto mb-8">
              Hear from our satisfied patients about their experiences at Tewkesbury Dental Practice.
            </p>
            
            {publicReviews.length > 0 && (
              <div className="flex flex-col items-center space-y-4">
                <div className="flex items-center space-x-2">
                  {renderStars(Math.round(averageRating))}
                  <span className="text-2xl ml-2">{averageRating.toFixed(1)}/5</span>
                </div>
                <p className="text-blue-100">
                  Based on {publicReviews.length} verified {publicReviews.length === 1 ? 'review' : 'reviews'}
                </p>
              </div>
            )}
          </div>
        </div>
      </section>

      {/* Statistics Section */}
      {publicReviews.length > 0 && (
        <section className="py-16 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-8 text-center">
              <div className="space-y-2">
                <div className="text-3xl text-teal-600">{publicReviews.length}</div>
                <div className="text-gray-600">Patient Reviews</div>
              </div>
              <div className="space-y-2">
                <div className="text-3xl text-teal-600">{averageRating.toFixed(1)}</div>
                <div className="text-gray-600">Average Rating</div>
              </div>
              <div className="space-y-2">
                <div className="text-3xl text-teal-600">
                  {publicReviews.filter(r => r.rating === 5).length}
                </div>
                <div className="text-gray-600">5-Star Reviews</div>
              </div>
              <div className="space-y-2">
                <div className="text-3xl text-teal-600">100%</div>
                <div className="text-gray-600">Satisfaction Rate</div>
              </div>
            </div>
          </div>
        </section>
      )}

      {/* Testimonials Grid */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {publicReviews.length > 0 ? (
            <>
              <div className="text-center mb-12">
                <h2 className="text-3xl lg:text-4xl mb-4">What Our Patients Say</h2>
                <p className="text-xl text-gray-600">
                  Real experiences from real patients who trust us with their dental care.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {publicReviews.map((review) => (
                  <Card key={review.id} className="hover:shadow-lg transition-shadow duration-300 relative">
                    <CardHeader className="pb-4">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-2">
                          <User className="h-8 w-8 text-gray-400 bg-gray-100 rounded-full p-1" />
                          <div>
                            <CardTitle className="text-lg">{review.patientName}</CardTitle>
                            <p className="text-sm text-gray-600">{review.treatmentReceived}</p>
                          </div>
                        </div>
                        <Quote className="h-8 w-8 text-teal-200" />
                      </div>
                      <div className="flex items-center space-x-2">
                        <div className="flex">{renderStars(review.rating)}</div>
                        <span className="text-sm text-gray-600">({review.rating}/5)</span>
                      </div>
                    </CardHeader>
                    
                    <CardContent className="space-y-4">
                      <p className="text-gray-700 italic">"{review.reviewText}"</p>
                      
                      <div className="flex items-center justify-between text-sm text-gray-500">
                        <div className="flex items-center">
                          <Calendar className="h-4 w-4 mr-1" />
                          {new Date(review.date).toLocaleDateString('en-GB', {
                            year: 'numeric',
                            month: 'long',
                            day: 'numeric'
                          })}
                        </div>
                        <Badge variant="outline" className="text-xs">
                          Verified Patient
                        </Badge>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </>
          ) : (
            <div className="text-center py-16">
              <Award className="h-16 w-16 text-gray-400 mx-auto mb-4" />
              <h2 className="text-2xl mb-4">Be Our First Reviewer!</h2>
              <p className="text-xl text-gray-600 mb-8">
                We'd love to hear about your experience with our dental practice.
              </p>
              <Card className="max-w-md mx-auto">
                <CardContent className="p-6">
                  <h3 className="text-lg mb-4">Share Your Experience</h3>
                  <p className="text-gray-600 mb-4">
                    Help other patients learn about the quality of care we provide by sharing your testimonial.
                  </p>
                  <Link to="/contact" className="text-teal-600 hover:text-teal-800 underline">
                    Contact us to leave a review →
                  </Link>
                </CardContent>
              </Card>
            </div>
          )}
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-teal-600 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl lg:text-4xl mb-4">Ready to Experience Exceptional Dental Care?</h2>
          <p className="text-xl mb-8 text-teal-100">
            Join our satisfied patients and discover why they recommend Tewkesbury Dental Practice.
          </p>
          <Link to="/contact">
            <Button  size="lg" className="bg-black text-teal-600:bg-gray-100">
              Contact Us
            </Button>
          </Link>
        </div>
      </section>
    </div>
  );
};

export default TestimonialsPage;