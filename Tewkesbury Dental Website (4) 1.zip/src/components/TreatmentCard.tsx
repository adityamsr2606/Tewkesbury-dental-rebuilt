import React from 'react';
import { Link } from 'react-router-dom';
import { Clock, ArrowRight } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface TreatmentCardProps {
  treatment: {
    id: string;
    title: string;
    description: string;
    image: string;
    duration: string;
    price: string;
    services: string[];
  };
}

const TreatmentCard: React.FC<TreatmentCardProps> = ({ treatment }) => {
  return (
    <Card className="overflow-hidden hover:shadow-lg transition-shadow duration-300">
      <div className="aspect-w-16 aspect-h-9">
        <ImageWithFallback
          src={treatment.image}
          alt={treatment.title}
          className="w-full h-48 object-cover"
        />
      </div>
      <CardHeader>
        <div className="flex justify-between items-start">
          <CardTitle className="text-xl">{treatment.title}</CardTitle>
          <Badge variant="secondary">{treatment.price}</Badge>
        </div>
        <p className="text-gray-600">{treatment.description}</p>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center space-x-4 text-sm text-gray-500">
          <div className="flex items-center">
            <Clock className="h-4 w-4 mr-1" />
            {treatment.duration}
          </div>
        </div>
        
        <div>
          <h4 className="mb-2">Services Include:</h4>
          <ul className="text-sm text-gray-600 space-y-1">
            {treatment.services.slice(0, 3).map((service, index) => (
              <li key={index} className="flex items-center">
                <div className="w-1.5 h-1.5 bg-teal-600 rounded-full mr-2"></div>
                {service}
              </li>
            ))}
            {treatment.services.length > 3 && (
              <li className="text-teal-600">+ {treatment.services.length - 3} more services</li>
            )}
          </ul>
        </div>

        <div className="flex space-x-2">
          <Link to="/appointment" className="flex-1">
            <Button variant="outline" className="w-full">
              Book Now
            </Button>
          </Link>
          <Button variant="outline" size="icon" className="border-teal-600 text-teal-600 hover:bg-teal-50">
            <ArrowRight className="h-4 w-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default TreatmentCard;