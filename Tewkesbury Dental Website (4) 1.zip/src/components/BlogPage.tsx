import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Calendar, Clock, User, ArrowLeft, Tag } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from './ui/dialog';
import { useDataStore } from './data/dataStore';

const BlogPage = () => {
  const { blogPosts } = useDataStore();
  const [selectedPost, setSelectedPost] = useState(null);
  const [isArticleDialogOpen, setIsArticleDialogOpen] = useState(false);
  
  // Filter published blog posts
  const publishedPosts = blogPosts.filter(post => post.isPublished);

  const openFullArticle = (post) => {
    setSelectedPost(post);
    setIsArticleDialogOpen(true);
  };

  const closeFullArticle = () => {
    setSelectedPost(null);
    setIsArticleDialogOpen(false);
  };

  // Function to render markdown-like content as HTML
  const renderContent = (content) => {
    // Simple markdown parsing for headers and paragraphs
    return content.split('\n').map((line, index) => {
      if (line.startsWith('# ')) {
        return <h1 key={index} className="text-3xl mb-4 mt-6">{line.slice(2)}</h1>;
      } else if (line.startsWith('## ')) {
        return <h2 key={index} className="text-2xl mb-3 mt-5">{line.slice(3)}</h2>;
      } else if (line.startsWith('### ')) {
        return <h3 key={index} className="text-xl mb-2 mt-4">{line.slice(4)}</h3>;
      } else if (line.startsWith('- ')) {
        return <li key={index} className="ml-4">{line.slice(2)}</li>;
      } else if (line.trim() === '') {
        return <br key={index} />;
      } else {
        return <p key={index} className="mb-3 leading-relaxed">{line}</p>;
      }
    });
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-r from-blue-600 to-teal-600 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl lg:text-6xl mb-6">Dental Health Blog</h1>
            <p className="text-xl lg:text-2xl text-blue-100 max-w-3xl mx-auto">
              Expert insights, tips, and the latest developments in dental care 
              from our experienced dental professionals.
            </p>
          </div>
        </div>
      </section>

      {/* Blog Posts */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {publishedPosts.length > 0 ? (
            <>
              <div className="text-center mb-12">
                <h2 className="text-3xl lg:text-4xl mb-4">Latest Articles</h2>
                <p className="text-xl text-gray-600">
                  Stay informed with our dental health insights and professional advice.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {publishedPosts.map((post) => (
                  <Card key={post.id} className="flex flex-col overflow-hidden hover:shadow-lg transition-shadow duration-300 h-full">
                    <div className="aspect-[4/3] bg-gray-200">
                      <img 
                        src={post.image} 
                        alt={post.title}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    
                    <CardHeader className="flex-shrink-0">
                      <div className="flex items-center space-x-2 text-sm text-gray-600 mb-2">
                        <Badge variant="outline">{post.category}</Badge>
                        <span>•</span>
                        <div className="flex items-center">
                          <Clock className="h-4 w-4 mr-1" />
                          {post.readTime}
                        </div>
                      </div>
                      <CardTitle className="text-xl leading-tight line-clamp-2">{post.title}</CardTitle>
                    </CardHeader>
                    
                    <CardContent className="flex flex-col flex-1 space-y-4">
                      <p className="text-gray-600 line-clamp-3 flex-1">{post.excerpt}</p>
                      
                      <div className="flex items-center justify-between text-sm text-gray-500">
                        <div className="flex items-center">
                          <User className="h-4 w-4 mr-1" />
                          {post.author}
                        </div>
                        <div className="flex items-center">
                          <Calendar className="h-4 w-4 mr-1" />
                          {new Date(post.date).toLocaleDateString('en-GB', {
                            year: 'numeric',
                            month: 'long',
                            day: 'numeric'
                          })}
                        </div>
                      </div>

                      {post.tags && post.tags.length > 0 && (
                        <div className="flex flex-wrap gap-1">
                          {post.tags.map((tag, index) => (
                            <Badge key={index} variant="secondary" className="text-xs">
                              <Tag className="h-3 w-3 mr-1" />
                              {tag}
                            </Badge>
                          ))}
                        </div>
                      )}
                      
                      <div className="flex space-x-2 pt-4 mt-auto">
                        <Button 
                          onClick={() => openFullArticle(post)}
                          className="flex-1"
                        >
                          Read Full Article
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </>
          ) : (
            <div className="text-center py-16">
              <h2 className="text-2xl mb-4">Coming Soon</h2>
              <p className="text-xl text-gray-600 mb-8">
                We're currently preparing informative articles about dental health and care.
              </p>
              <Card className="max-w-md mx-auto">
                <CardContent className="p-6">
                  <h3 className="text-lg mb-4">Stay Informed</h3>
                  <p className="text-gray-600 mb-4">
                    Check back soon for expert dental advice and health tips from our experienced team.
                  </p>
                  <Link to="/contact" className="text-teal-600 hover:text-teal-800 underline">
                    Contact us for immediate dental questions →
                  </Link>
                </CardContent>
              </Card>
            </div>
          )}
        </div>
      </section>

      {/* Full Article Dialog */}
      {selectedPost && (
        <Dialog open={isArticleDialogOpen} onOpenChange={setIsArticleDialogOpen}>
          <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <div className="flex items-center space-x-2 mb-4">
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={closeFullArticle}
                  className="mb-2"
                >
                  <ArrowLeft className="h-4 w-4 mr-1" />
                  Back to Articles
                </Button>
              </div>
              <div className="aspect-video bg-gray-200 rounded-lg overflow-hidden mb-4">
                <img 
                  src={selectedPost.image} 
                  alt={selectedPost.title}
                  className="w-full h-full object-cover"
                />
              </div>
              <DialogTitle className="text-2xl">{selectedPost.title}</DialogTitle>
              <DialogDescription>
                Full article by {selectedPost.author} - {selectedPost.readTime}
              </DialogDescription>
              <div className="flex items-center space-x-4 text-sm text-gray-600">
                <div className="flex items-center">
                  <User className="h-4 w-4 mr-1" />
                  {selectedPost.author}
                </div>
                <div className="flex items-center">
                  <Calendar className="h-4 w-4 mr-1" />
                  {new Date(selectedPost.date).toLocaleDateString('en-GB', {
                    year: 'numeric',
                    month: 'long',
                    day: 'numeric'
                  })}
                </div>
                <div className="flex items-center">
                  <Clock className="h-4 w-4 mr-1" />
                  {selectedPost.readTime}
                </div>
                <Badge variant="outline">{selectedPost.category}</Badge>
              </div>
            </DialogHeader>
            
            <div className="space-y-4 text-gray-700 leading-relaxed">
              {selectedPost.fullContent ? 
                renderContent(selectedPost.fullContent) : 
                <p>{selectedPost.content}</p>
              }
            </div>

            {selectedPost.tags && selectedPost.tags.length > 0 && (
              <div className="border-t pt-4 mt-6">
                <h4 className="text-sm text-gray-500 mb-2">Tags:</h4>
                <div className="flex flex-wrap gap-2">
                  {selectedPost.tags.map((tag, index) => (
                    <Badge key={index} variant="secondary" className="text-xs">
                      <Tag className="h-3 w-3 mr-1" />
                      {tag}
                    </Badge>
                  ))}
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
};

export default BlogPage;