import React from 'react';
import { Link } from 'react-router-dom';
import { Phone, Mail, MapPin } from 'lucide-react';

const treatments = [
  'General Dentistry',
  'Tooth Whitening',
  'Dental Veneers',
  'Dental Crowns',
  'Dental Bridges',
  'Dental Implants',
  'Root Canal Treatment',
  'Tooth Extraction',
];

const Footer = () => {
  return (
    <footer className="bg-gray-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Dental Treatments */}
           
           <div className="px-[-30px] py-[0px] mx-[40px] my-[0px]">
            <h3 className="text-white-xl mb-4"> </h3>
            <ul className="space-y-2"> 
              {treatments.map((treatment, index) => (
                <li key={index}>
                  <Link
                    to="/treatments"
                    className="text-gray-300 hover:text-teal-400 transition-colors duration-200">
                  
                    {treatment}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
            

          {/* Opening Hours */}
          <div className="px-[-30px] py-[0px] mx-[40px] my-[0px]">
            <h3 className="text-xl mb-4">Opening Hours</h3>
            <div className="space-y-2 text-gray-300">
              <div className="flex justify-between items-center">
                <span className="min-w-0 pr-3">Monday:</span>
                <span className="text-right">8:30am - 5:30pm</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="min-w-0 pr-3">Tuesday:</span>
                <span className="text-right">8:30am - 5:30pm</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="min-w-0 pr-3">Wednesday:</span>
                <span className="text-right">8:30am - 5:30pm</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="min-w-0 pr-3">Thursday:</span>
                <span className="text-right">8:30am - 5:30pm</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="min-w-0 pr-3">Friday:</span>
                <span className="text-right">8:30am - 5:30pm</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="min-w-0 pr-3">Saturday:</span>
                <span className="text-right">9:00am - 1:00pm</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="min-w-0 pr-3">Sunday:</span>
                <span className="text-right">Closed</span>
              </div>
            </div>
          </div>

          {/* Contact Info */}
          <div>
            <h3 className="text-xl mb-4">Contact Information</h3>
            <div className="space-y-3 text-gray-300">
              <div className="flex items-center space-x-3">
                <Phone size={16} />
                <span>01684 295727</span>
              </div>
              <div className="flex items-center space-x-3">
                <Mail size={16} />
                <span>info@tewkesburydental.co.uk</span>
              </div>
              <div className="flex items-start space-x-3">
                <MapPin size={16} className="mt-1" />
                <div>
                  <p>Tewkesbury Dental Practice</p>
                  <p>123 High Street</p>
                  <p>Tewkesbury, GL20 5AL</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
          <p>&copy; 2024 Tewkesbury Dental Practice. All rights reserved.</p>
          <div className="mt-4 flex justify-center space-x-4">
            <Link
              to="/admin"
              className="text-gray-500 hover:text-gray-300 transition-colors duration-200 text-sm"
            >
              Admin Login
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;