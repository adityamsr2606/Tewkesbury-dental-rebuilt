import React from 'react';
import { Link } from 'react-router-dom';
import { Star, Clock, Shield, Award } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { ImageWithFallback } from './figma/ImageWithFallback';

const FacialAestheticsPage = () => {
  const treatments = [
    {
      id: 'botox',
      title: 'Botox® Treatment',
      description: 'Reduce fine lines and wrinkles with safe, effective anti-wrinkle injections.',
      price: 'From £180',
      duration: '30 minutes',
      areas: ['Forehead lines', 'Crow\'s feet', 'Frown lines', 'Bunny lines'],
      image: 'https://images.unsplash.com/photo-1683520701490-7172fa20c8f1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHhkZW50YWwlMjB0ZWFtJTIwcHJvZmVzc2lvbmFsc3xlbnwxfHx8fDE3NTYxOTc2Mjd8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral'
    },
    {
      id: 'dermal-fillers',
      title: 'Dermal Fillers',
      description: 'Restore volume and smooth wrinkles with hyaluronic acid-based fillers.',
      price: 'From £320',
      duration: '45 minutes',
      areas: ['Nasolabial folds', 'Marionette lines', 'Cheek enhancement', 'Tear troughs'],
      image: 'https://images.unsplash.com/photo-1675526607070-f5cbd71dde92?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0b290aCUyMHdoaXRlbmluZyUyMHNtaWxlfGVufDF8fHx8MTc1NjI4NzU5NHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral'
    },
    {
      id: 'lip-enhancement',
      title: 'Lip Enhancement',
      description: 'Enhance lip volume and definition for a natural, beautiful result.',
      price: 'From £280',
      duration: '30 minutes',
      areas: ['Lip volume', 'Lip definition', 'Lip symmetry', 'Perioral lines'],
      image: 'https://images.unsplash.com/photo-1593022356269-609ed284b3c3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHhkZW50YWwlMjBoeWdpZW5lJTIwdGVldGh8ZW58MXx8fHwxNzU2Mjg3NTk0fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral'
    }
  ];

  const benefits = [
    {
      icon: <Award className="h-8 w-8 text-teal-600" />,
      title: 'Expert Practitioners',
      description: 'Our dentists are specially trained in facial aesthetics and anatomy.'
    },
    {
      icon: <Shield className="h-8 w-8 text-teal-600" />,
      title: 'Medical Setting',
      description: 'Treatments performed in a safe, sterile medical environment.'
    },
    {
      icon: <Star className="h-8 w-8 text-teal-600" />,
      title: 'Natural Results',
      description: 'Subtle enhancements that maintain your natural beauty.'
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-teal-600 to-blue-600 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl lg:text-6xl mb-6">Facial Aesthetics</h1>
          <p className="text-xl lg:text-2xl text-teal-100 max-w-3xl mx-auto">
            Enhance your natural beauty with our professional facial aesthetic treatments. 
            Safe, effective procedures performed by qualified dental professionals.
          </p>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl lg:text-4xl mb-4">Why Choose Us for Facial Aesthetics?</h2>
            <p className="text-xl text-gray-600">
              Our dental professionals bring medical expertise and artistic skill to facial aesthetics.
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {benefits.map((benefit, index) => (
              <Card key={index} className="text-center p-6">
                <CardContent className="space-y-4">
                  <div className="flex justify-center">{benefit.icon}</div>
                  <h3 className="text-xl">{benefit.title}</h3>
                  <p className="text-gray-600">{benefit.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Treatments Section */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl lg:text-4xl mb-4">Our Facial Aesthetic Treatments</h2>
            <p className="text-xl text-gray-600">
              Professional treatments to help you look and feel your best.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {treatments.map((treatment) => (
              <Card key={treatment.id} className="overflow-hidden hover:shadow-lg transition-shadow duration-300">
                <div className="aspect-w-16 aspect-h-9">
                  <ImageWithFallback
                    src={treatment.image}
                    alt={treatment.title}
                    className="w-full h-48 object-cover"
                  />
                </div>
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <CardTitle className="text-xl">{treatment.title}</CardTitle>
                    <Badge variant="secondary">{treatment.price}</Badge>
                  </div>
                  <p className="text-gray-600">{treatment.description}</p>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center text-sm text-gray-500">
                    <Clock className="h-4 w-4 mr-1" />
                    {treatment.duration}
                  </div>
                  
                  <div>
                    <h4 className="mb-2">Treatment Areas:</h4>
                    <ul className="text-sm text-gray-600 space-y-1">
                      {treatment.areas.map((area, index) => (
                        <li key={index} className="flex items-center">
                          <div className="w-1.5 h-1.5 bg-teal-600 rounded-full mr-2"></div>
                          {area}
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div className="flex space-x-2">
                    <Link to="/book" className="flex-1">
                      <Button variant="outline" className="w-full">
                        Book Consultation
                      </Button>
                    </Link>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Process Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl lg:text-4xl mb-4">Treatment Process</h2>
            <p className="text-xl text-gray-600">
              What to expect during your facial aesthetic treatment journey.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-teal-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl text-teal-600">1</span>
              </div>
              <h3 className="text-lg mb-2">Consultation</h3>
              <p className="text-gray-600 text-sm">
                Discuss your goals and assess suitability for treatment
              </p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-teal-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl text-teal-600">2</span>
              </div>
              <h3 className="text-lg mb-2">Treatment Plan</h3>
              <p className="text-gray-600 text-sm">
                Create a personalized treatment plan tailored to you
              </p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-teal-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl text-teal-600">3</span>
              </div>
              <h3 className="text-lg mb-2">Treatment</h3>
              <p className="text-gray-600 text-sm">
                Professional treatment using the latest techniques
              </p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-teal-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl text-teal-600">4</span>
              </div>
              <h3 className="text-lg mb-2">Follow-up</h3>
              <p className="text-gray-600 text-sm">
                Review results and plan any follow-up treatments
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl lg:text-4xl mb-4">Frequently Asked Questions</h2>
          </div>

          <div className="space-y-6">
            <Card>
              <CardContent className="p-6">
                <h3 className="text-lg mb-2">Are facial aesthetic treatments safe?</h3>
                <p className="text-gray-600">
                  Yes, when performed by qualified practitioners in a medical setting. 
                  Our dental professionals are specially trained in facial anatomy and injection techniques.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <h3 className="text-lg mb-2">How long do results last?</h3>
                <p className="text-gray-600">
                  Botox typically lasts 3-4 months, while dermal fillers can last 6-18 months 
                  depending on the type and area treated.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <h3 className="text-lg mb-2">Is there any downtime?</h3>
                <p className="text-gray-600">
                  Most treatments have minimal downtime. You may experience slight swelling or bruising 
                  for a few days, but you can typically return to normal activities immediately.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-teal-600 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl lg:text-4xl mb-4">Ready to Enhance Your Natural Beauty?</h2>
          <p className="text-xl mb-8 text-teal-100">
            Book a consultation to discuss your aesthetic goals and create a personalized treatment plan.
          </p>
          <Link to="/contact">
            <Button  size="lg" className="bg-black text-teal-600:bg-gray-100">
              Contact Us
            </Button>
          </Link>
        </div>
      </section>
    </div>
  );
};

export default FacialAestheticsPage;