import React from 'react';
import { Clock, Info, CheckCircle } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Alert, AlertDescription } from './ui/alert';
import { useDataStore } from './data/dataStore';

const FeesPage = () => {
  const { treatments } = useDataStore();
  
  // Group treatments by category
  const treatmentsByCategory = treatments
    .filter(treatment => treatment.isActive)
    .reduce((acc, treatment) => {
      if (!acc[treatment.category]) {
        acc[treatment.category] = [];
      }
      acc[treatment.category].push(treatment);
      return acc;
    }, {});

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl mb-4">Treatment Fees</h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Transparent pricing for all our dental treatments. We believe in clear, 
            upfront pricing with no hidden costs.
          </p>
        </div>

        {/* Payment Information */}
        <div className="mb-12">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Info className="mr-2 h-5 w-5" />
                Pricing Information
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h3 className="mb-3">What's Included</h3>
                  <ul className="space-y-2 text-gray-600">
                    <li className="flex items-center">
                      <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                      Comprehensive consultation
                    </li>
                    <li className="flex items-center">
                      <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                      All necessary materials
                    </li>
                    <li className="flex items-center">
                      <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                      Aftercare instructions
                    </li>
                    <li className="flex items-center">
                      <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                      Follow-up appointments when needed
                    </li>
                    <li className="flex items-center">
                      <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                      Professional expertise and care
                    </li>
                  </ul>
                </div>
                <div>
                  <h3 className="mb-3">Important Notes</h3>
                  <ul className="space-y-2 text-gray-600">
                    <li>• Prices may vary based on individual requirements</li>
                    <li>• Free initial consultation for treatment planning</li>
                    <li>• Payment plans available for extensive treatments</li>
                    <li>• Insurance claims assistance provided</li>
                    <li>• All prices include VAT where applicable</li>
                    <li>• Emergency appointments may incur additional charges</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Treatment Categories */}
        <div className="space-y-12">
          {Object.entries(treatmentsByCategory).map(([category, categoryTreatments], categoryIndex) => (
            <div key={category}>
              <h2 className="text-3xl mb-6">{category}</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {categoryTreatments.map((treatment, treatmentIndex) => (
                  <Card key={treatment.id} className="hover:shadow-lg transition-shadow duration-300">
                    <CardHeader>
                      <div className="flex justify-between items-start">
                        <CardTitle className="text-lg">{treatment.title}</CardTitle>
                        <Badge variant="secondary" className="text-lg px-3 py-1">
                          {treatment.price}
                        </Badge>
                      </div>
                      <div className="flex items-center text-sm text-gray-600">
                        <Clock className="h-4 w-4 mr-1" />
                        {treatment.duration}
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <p className="text-gray-600">{treatment.description}</p>
                      
                      {treatment.services && treatment.services.length > 0 && (
                        <div>
                          <h4 className="text-sm mb-2">Services Included:</h4>
                          <ul className="space-y-1">
                            {treatment.services.map((service, index) => (
                              <li key={index} className="text-sm text-gray-600 flex items-center">
                                <div className="w-1 h-1 bg-teal-600 rounded-full mr-2"></div>
                                {service}
                              </li>
                            ))}
                          </ul>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          ))}
        </div>

        {/* Contact CTA */}
        <div className="mt-16">
          <Alert className="border-teal-200 bg-teal-50">
            <Info className="h-4 w-4" />
            <AlertDescription className="text-teal-700">
              <strong>Need more information?</strong> Contact us at{' '}
              <a href="tel:01684295727" className="underline hover:text-teal-800">
                01684 295727
              </a>{' '}
              or{' '}
              <a href="mailto:info@tewkesburydental.co.uk" className="underline hover:text-teal-800">
                info@tewkesburydental.co.uk
              </a>{' '}
              for personalized treatment plans and pricing.
            </AlertDescription>
          </Alert>
        </div>
      </div>
    </div>
  );
};

export default FeesPage;