import React from 'react';
import { Link } from 'react-router-dom';
import { Star, Phone, Calendar, Shield, Award, Users, Clock, MapPin, Mail } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { ImageWithFallback } from './figma/ImageWithFallback';

const HomePage = () => {
  const features = [
    {
      icon: <Shield className="h-8 w-8 text-teal-600" />,
      title: 'Professional Care',
      description: 'Expert dental care with state-of-the-art equipment and proven techniques.',
    },
    {
      icon: <Users className="h-8 w-8 text-teal-600" />,
      title: 'Experienced Team',
      description: 'Our qualified dental professionals provide personalized treatment plans.',
    },
    {
      icon: <Award className="h-8 w-8 text-teal-600" />,
      title: 'Quality Service',
      description: 'Committed to delivering exceptional dental care and patient satisfaction.',
    },
    {
      icon: <Clock className="h-8 w-8 text-teal-600" />,
      title: 'Flexible Hours',
      description: 'Convenient appointment times including Saturday morning sessions.',
    },
  ];

  const services = [
    {
      title: 'General Dentistry',
      description: 'Comprehensive dental care including checkups, cleanings, and preventive treatments.',
      image: 'https://images.unsplash.com/photo-1642844819197-5f5f21b89ff8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkZW50YWwlMjBjbGluaWMlMjBtb2Rlcm58ZW58MXx8fHwxNzU2Mjc5MTgyfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    },
    {
      title: 'Cosmetic Dentistry',
      description: 'Transform your smile with tooth whitening, veneers, and aesthetic treatments.',
      image: 'https://images.unsplash.com/photo-1675526607070-f5cbd71dde92?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0b290aCUyMHdoaXRlbmluZyUyMHNtaWxlfGVufDF8fHx8MTc1NjI4NzU5NHww&ixlib=rb-4.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    },
    {
      title: 'Facial Aesthetics',
      description: 'Non-surgical facial treatments to enhance your natural beauty and confidence.',
      image: 'https://images.unsplash.com/photo-1683520701490-7172fa20c8f1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkZW50YWwlMjB0ZWFtJTIwcHJvZmVzc2lvbmFsc3xlbnwxfHx8fDE3NTYxOTc2Mjd8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    },
  ];

  const testimonials = [
    {
      name: 'Sarah Johnson',
      rating: 5,
      text: 'Excellent service and very professional staff. My dental implant procedure was smooth and painless.',
    },
    {
      name: 'Michael Brown',
      rating: 5,
      text: 'The team at Tewkesbury Dental made me feel comfortable throughout my treatment. Highly recommended!',
    },
    {
      name: 'Emma Wilson',
      rating: 5,
      text: 'Outstanding care and attention to detail. The tooth whitening results exceeded my expectations.',
    },
  ];

  return (
    <div className="space-y-16">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-r from-teal-600 to-blue-600 text-white">
        <div className="absolute inset-0 bg-black opacity-20"></div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-6">
              <h1 className="text-4xl lg:text-6xl leading-tight">
                Welcome to Tewkesbury Dental Practice
              </h1>
              <p className="text-xl lg:text-2xl text-teal-100">
                Providing exceptional dental care in the heart of Tewkesbury for over 30 years.
                Your smile is our priority.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Link to="/book">
                  <Button variant="primary" size="lg" className="bg-white text-teal-600 hover:bg-teal-50 hover:text-teal-700 border-white">
                    <Calendar className="mr-2 h-5 w-5" />
                    Book Appointment
                  </Button>
                </Link>
                <Button variant="primary" size="lg" className="bg-white text-teal-600 hover:bg-teal-50 hover:text-teal-700 border-white">
                  <Phone className="mr-2 h-5 w-5" />
                  01684 295727
                </Button>
              </div>
            </div>
            <div className="hidden lg:block">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1704455306925-1401c3012117?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkZW50YWwlMjB0cmVhdG1lbnQlMjBjaGFpcnxlbnwxfHx8fDE3NTYyODc1OTJ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                alt="Modern dental treatment room"
                className="rounded-lg shadow-xl w-full h-96 object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl lg:text-4xl mb-4">Why Choose Tewkesbury Dental?</h2>
          <p className="text-xl text-gray-600">
            We're committed to providing the highest standard of dental care in a comfortable environment.
          </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <Card key={index} className="text-center p-6 hover:shadow-lg transition-shadow duration-300">
              <CardContent className="space-y-4">
                <div className="flex justify-center">{feature.icon}</div>
                <h3 className="text-xl">{feature.title}</h3>
                <p className="text-gray-600">{feature.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      {/* Services Section */}
      <section className="bg-gray-100 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl lg:text-4xl mb-4">Our Services</h2>
            <p className="text-xl text-gray-600">
              Comprehensive dental and aesthetic treatments tailored to your needs.
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {services.map((service, index) => (
              <Card key={index} className="overflow-hidden hover:shadow-lg transition-shadow duration-300">
                <div className="aspect-w-16 aspect-h-9">
                  <ImageWithFallback
                    src={service.image}
                    alt={service.title}
                    className="w-full h-48 object-cover"
                  />
                </div>
                <CardContent className="p-6">
                  <h3 className="text-xl mb-3">{service.title}</h3>
                  <p className="text-gray-600 mb-4">{service.description}</p>
                  <Link to="/treatments">
                    <Button variant="outline-secondary" className="w-full">
                      Learn More
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl lg:text-4xl mb-4">What Our Patients Say</h2>
          <p className="text-xl text-gray-600">
            Read reviews from our satisfied patients who trust us with their dental care.
          </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <Card key={index} className="p-6">
              <CardContent className="space-y-4">
                <div className="flex justify-center space-x-1">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="h-5 w-5 fill-yellow-400 text-yellow-400" />
                  ))}
                </div>
                <p className="text-gray-600 italic">"{testimonial.text}"</p>
                <p className="text-center">{testimonial.name}</p>
              </CardContent>
            </Card>
          ))}
        </div>
        <div className="text-center mt-8">
          <Link to="/testimonials">
            <Button variant="outline-secondary" size="lg">
              Read More Reviews
            </Button>
          </Link>
        </div>
      </section>

      {/* Contact Information Section */}
      <section className="bg-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl lg:text-4xl mb-4">Visit Our Practice</h2>
            <p className="text-xl text-gray-600">
              Convenient location with easy parking and flexible appointment times.
            </p>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            {/* Contact Information */}
            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card className="p-6 hover:shadow-lg transition-shadow">
                  <div className="flex items-center space-x-4">
                    <div className="bg-teal-100 p-3 rounded-lg">
                      <Phone className="h-6 w-6 text-teal-600" />
                    </div>
                    <div>
                      <h3 className="text-lg mb-1">Call Us</h3>
                      <a 
                        href="tel:01684295727" 
                        className="text-teal-600 hover:text-teal-800 text-lg transition-colors"
                      >
                        01684 295727
                      </a>
                    </div>
                  </div>
                </Card>

                <Card className="p-6 hover:shadow-lg transition-shadow">
                  <div className="flex items-center space-x-4">
                    <div className="bg-blue-100 p-3 rounded-lg">
                      <Mail className="h-6 w-6 text-blue-600" />
                    </div>
                    <div>
                      <h3 className="text-lg mb-1">Email Us</h3>
                      <a 
                        href="mailto:info@tewkesburydental.co.uk" 
                        className="text-blue-600 hover:text-blue-800 transition-colors text-sm"
                      >
                        info@tewkesburydental.co.uk
                      </a>
                    </div>
                  </div>
                </Card>
              </div>

              <Card className="p-6 hover:shadow-lg transition-shadow">
                <div className="flex items-start space-x-4">
                  <div className="bg-green-100 p-3 rounded-lg">
                    <MapPin className="h-6 w-6 text-green-600" />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-lg mb-2">Visit Our Practice</h3>
                    <p className="text-gray-700 mb-2">
                      Tewkesbury Dental Practice<br />
                      123 High Street<br />
                      Tewkesbury, GL20 5AL
                    </p>
                    <p className="text-sm text-gray-600">Free parking available</p>
                  </div>
                </div>
              </Card>
            </div>

            {/* Opening Hours */}
            <div>
              <Card className="p-8">
                <h3 className="text-2xl mb-6 text-center">Opening Hours</h3>
                <div className="space-y-4">
                  <div className="flex justify-between items-center py-3 border-b border-gray-100">
                    <span className="text-gray-700">Monday - Friday</span>
                    <span className="text-teal-600">8:30 AM - 5:30 PM</span>
                  </div>
                  <div className="flex justify-between items-center py-3 border-b border-gray-100">
                    <span className="text-gray-700">Saturday</span>
                    <span className="text-teal-600">9:00 AM - 1:00 PM</span>
                  </div>
                  <div className="flex justify-between items-center py-3">
                    <span className="text-gray-700">Sunday</span>
                    <span className="text-gray-500">Closed</span>
                  </div>
                </div>
                
                <div className="mt-8">
                  <div className="bg-red-50 p-4 rounded-lg mb-6">
                    <h4 className="text-lg text-red-800 mb-2">Emergency Care</h4>
                    <p className="text-sm text-red-600 mb-2">
                      24/7 emergency dental care available
                    </p>
                    <a 
                      href="tel:01684295727" 
                      className="text-red-600 hover:text-red-800 underline"
                    >
                      Call 01684 295727
                    </a>
                  </div>
                  
                  <Link to="/book">
                    <Button variant="primary" size="lg" className="w-full">
                      <Calendar className="mr-2 h-4 w-4" />
                      Book an Appointment
                    </Button>
                  </Link>
                </div>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-teal-600 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl lg:text-4xl mb-4">Ready to Transform Your Smile?</h2>
          <p className="text-xl mb-8 text-teal-100">
            Book your consultation today and take the first step towards optimal dental health.
          </p>
          <Link to="/contact">
            <Button size="lg" className="bg-black text-teal-600:bg-gray-100">
              Contact Us
            </Button>
          </Link>
        </div>
      </section>
    </div>
  );
};

export default HomePage;