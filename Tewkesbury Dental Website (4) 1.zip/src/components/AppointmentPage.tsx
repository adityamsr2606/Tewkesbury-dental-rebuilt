import React, { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Calendar, Clock, User, Mail, Phone, MessageSquare, AlertCircle, CheckCircle } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Alert, AlertDescription } from './ui/alert';
import { RadioGroup, RadioGroupItem } from './ui/radio-group';
import { useDataStore } from './data/dataStore';

const AppointmentPage = () => {
  const [searchParams] = useSearchParams();
  const bookingType = searchParams.get('type') || 'appointment';
  
  const { addBooking, treatments, doctors } = useDataStore();
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    preferredDate: '',
    preferredTime: '',
    treatmentType: '',
    urgency: 'routine',
    message: '',
  });
  const [errors, setErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  // Set treatment type based on booking type
  useEffect(() => {
    if (bookingType === 'membership') {
      setFormData(prev => ({ ...prev, treatmentType: 'Dental Membership' }));
    }
  }, [bookingType]);

  const activetreatments = treatments.filter(t => t.isActive);
  const activeDoctors = doctors.filter(d => d.isActive);

  const validateForm = () => {
    const newErrors = {};
    
    if (!formData.firstName.trim()) {
      newErrors.firstName = 'First name is required';
    }
    
    if (!formData.lastName.trim()) {
      newErrors.lastName = 'Last name is required';
    }
    
    if (!formData.email.trim()) {
      newErrors.email = 'Email is required';
    } else if (!formData.email.includes('@')) {
      newErrors.email = 'Please enter a valid email address';
    }
    
    if (!formData.phone.trim()) {
      newErrors.phone = 'Phone number is required';
    }
    
    if (!formData.preferredDate) {
      newErrors.preferredDate = 'Preferred date is required';
    } else {
      const selectedDate = new Date(formData.preferredDate);
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      
      if (selectedDate < today) {
        newErrors.preferredDate = 'Please select a future date';
      }
    }
    
    if (!formData.preferredTime) {
      newErrors.preferredTime = 'Preferred time is required';
    }
    
    if (!formData.treatmentType && bookingType !== 'membership') {
      newErrors.treatmentType = 'Please select a treatment type';
    }
    
    return newErrors;
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    // Clear error when user starts typing
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: '' }));
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const newErrors = validateForm();
    
    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    setIsSubmitting(true);
    setErrors({});

    try {
      // Mock form submission delay
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Add booking to store
      const bookingData = {
        ...formData,
        status: 'pending',
        paymentStatus: 'pending',
        bookingType: bookingType === 'membership' ? 'membership' : 'appointment'
      };
      
      addBooking(bookingData);
      
      setSubmitted(true);
      
      // Reset form
      setFormData({
        firstName: '',
        lastName: '',
        email: '',
        phone: '',
        preferredDate: '',
        preferredTime: '',
        treatmentType: bookingType === 'membership' ? 'Dental Membership' : '',
        urgency: 'routine',
        message: '',
      });
    } catch (error) {
      setErrors({ submit: 'Failed to submit appointment request. Please try again.' });
    } finally {
      setIsSubmitting(false);
    }
  };

  const timeSlots = [
    '9:00 AM', '9:30 AM', '10:00 AM', '10:30 AM', '11:00 AM', '11:30 AM',
    '2:00 PM', '2:30 PM', '3:00 PM', '3:30 PM', '4:00 PM', '4:30 PM', '5:00 PM'
  ];

  // Get minimum date (tomorrow)
  const getMinDate = () => {
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    return tomorrow.toISOString().split('T')[0];
  };

  if (submitted) {
    return (
      <div className="min-h-screen bg-gray-50 py-12">
        <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8">
          <Card className="text-center p-8">
            <CardContent className="space-y-6">
              <CheckCircle className="h-16 w-16 text-green-500 mx-auto" />
              <h1 className="text-3xl text-green-600">
                {bookingType === 'membership' ? 'Membership Request Submitted!' : 'Appointment Request Submitted!'}
              </h1>
              <div className="space-y-4 text-gray-600">
                <p className="text-lg">
                  Thank you! We have received your {bookingType === 'membership' ? 'membership' : 'appointment'} request.
                </p>
                <p>
                  We will contact you within 24 hours to confirm your {bookingType === 'membership' ? 'membership enrollment' : 'appointment'}.
                </p>
                <p>
                  For urgent matters, please call us directly at{' '}
                  <a href="tel:01684295727" className="text-teal-600 hover:text-teal-800 underline">
                    01684 295727
                  </a>.
                </p>
              </div>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button 
                  onClick={() => {
                    setSubmitted(false);
                    if (bookingType === 'membership') {
                      setFormData(prev => ({ ...prev, treatmentType: 'Dental Membership' }));
                    }
                  }}
                  variant="outline"
                >
                  Make Another {bookingType === 'membership' ? 'Request' : 'Appointment'}
                </Button>
                <Button onClick={() => window.location.href = '/'} variant="primary">
                  Return to Home
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl mb-4">
            {bookingType === 'membership' ? 'Join Our Dental Membership' : 'Book an Appointment'}
          </h1>
          <p className="text-xl text-gray-600">
            {bookingType === 'membership' 
              ? 'Complete the form below to start your membership enrollment process.'
              : 'Complete the form below and we\'ll contact you to confirm your appointment.'
            }
          </p>
        </div>

        {bookingType === 'membership' && (
          <Alert className="mb-8 border-blue-200 bg-blue-50">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription className="text-blue-700">
              <strong>Dental Membership Benefits:</strong> £29/month includes 2 annual checkups, 
              2 professional cleanings, 20% discount on treatments, and emergency care coverage.
            </AlertDescription>
          </Alert>
        )}

        <Card className="p-8">
          <CardHeader>
            <CardTitle className="text-2xl">
              {bookingType === 'membership' ? 'Membership Information' : 'Appointment Details'}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-8">
              {/* Personal Information */}
              <div>
                <h3 className="text-lg mb-4">Personal Information</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <Label htmlFor="firstName">First Name *</Label>
                    <div className="relative mt-2">
                      <User className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                      <Input
                        id="firstName"
                        name="firstName"
                        value={formData.firstName}
                        onChange={handleInputChange}
                        className={`pl-10 h-12 ${errors.firstName ? 'border-red-500' : ''}`}
                        placeholder="Enter your first name"
                      />
                    </div>
                    {errors.firstName && (
                      <p className="text-red-500 text-sm mt-1">{errors.firstName}</p>
                    )}
                  </div>

                  <div>
                    <Label htmlFor="lastName">Last Name *</Label>
                    <div className="relative mt-2">
                      <User className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                      <Input
                        id="lastName"
                        name="lastName"
                        value={formData.lastName}
                        onChange={handleInputChange}
                        className={`pl-10 h-12 ${errors.lastName ? 'border-red-500' : ''}`}
                        placeholder="Enter your last name"
                      />
                    </div>
                    {errors.lastName && (
                      <p className="text-red-500 text-sm mt-1">{errors.lastName}</p>
                    )}
                  </div>

                  <div>
                    <Label htmlFor="email">Email Address *</Label>
                    <div className="relative mt-2">
                      <Mail className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                      <Input
                        id="email"
                        name="email"
                        type="email"
                        value={formData.email}
                        onChange={handleInputChange}
                        className={`pl-10 h-12 ${errors.email ? 'border-red-500' : ''}`}
                        placeholder="Enter your email address"
                      />
                    </div>
                    {errors.email && (
                      <p className="text-red-500 text-sm mt-1">{errors.email}</p>
                    )}
                  </div>

                  <div>
                    <Label htmlFor="phone">Phone Number *</Label>
                    <div className="relative mt-2">
                      <Phone className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                      <Input
                        id="phone"
                        name="phone"
                        type="tel"
                        value={formData.phone}
                        onChange={handleInputChange}
                        className={`pl-10 h-12 ${errors.phone ? 'border-red-500' : ''}`}
                        placeholder="Enter your phone number"
                      />
                    </div>
                    {errors.phone && (
                      <p className="text-red-500 text-sm mt-1">{errors.phone}</p>
                    )}
                  </div>
                </div>
              </div>

              {/* Appointment Details */}
              <div>
                <h3 className="text-lg mb-4">
                  {bookingType === 'membership' ? 'Preferred Initial Consultation' : 'Appointment Details'}
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <Label htmlFor="preferredDate">Preferred Date *</Label>
                    <div className="relative mt-2">
                      <Calendar className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                      <Input
                        id="preferredDate"
                        name="preferredDate"
                        type="date"
                        min={getMinDate()}
                        value={formData.preferredDate}
                        onChange={handleInputChange}
                        className={`pl-10 h-12 ${errors.preferredDate ? 'border-red-500' : ''}`}
                      />
                    </div>
                    {errors.preferredDate && (
                      <p className="text-red-500 text-sm mt-1">{errors.preferredDate}</p>
                    )}
                  </div>

                  <div>
                    <Label htmlFor="preferredTime">Preferred Time *</Label>
                    <Select 
                      value={formData.preferredTime} 
                      onValueChange={(value) => setFormData(prev => ({ ...prev, preferredTime: value }))}
                    >
                      <SelectTrigger className={`mt-2 h-12 ${errors.preferredTime ? 'border-red-500' : ''}`}>
                        <Clock className="h-4 w-4 mr-2 text-gray-400" />
                        <SelectValue placeholder="Select preferred time" />
                      </SelectTrigger>
                      <SelectContent>
                        {timeSlots.map((time) => (
                          <SelectItem key={time} value={time}>
                            {time}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    {errors.preferredTime && (
                      <p className="text-red-500 text-sm mt-1">{errors.preferredTime}</p>
                    )}
                  </div>
                </div>

                {bookingType !== 'membership' && (
                  <div className="mt-6">
                    <Label htmlFor="treatmentType">Treatment Type *</Label>
                    <Select 
                      value={formData.treatmentType} 
                      onValueChange={(value) => setFormData(prev => ({ ...prev, treatmentType: value }))}
                    >
                      <SelectTrigger className={`mt-2 h-12 ${errors.treatmentType ? 'border-red-500' : ''}`}>
                        <SelectValue placeholder="Select treatment type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="General Checkup">General Checkup</SelectItem>
                        <SelectItem value="Consultation">Consultation</SelectItem>
                        {activetreatments.map((treatment) => (
                          <SelectItem key={treatment.id} value={treatment.title}>
                            {treatment.title} - {treatment.price}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    {errors.treatmentType && (
                      <p className="text-red-500 text-sm mt-1">{errors.treatmentType}</p>
                    )}
                  </div>
                )}

                <div className="mt-6">
                  <Label>
                    {bookingType === 'membership' ? 'Urgency Level' : 'Appointment Urgency'}
                  </Label>
                  <RadioGroup 
                    value={formData.urgency} 
                    onValueChange={(value) => setFormData(prev => ({ ...prev, urgency: value }))}
                    className="mt-3"
                  >
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="routine" id="routine" />
                      <Label htmlFor="routine">Routine (No pain or discomfort)</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="urgent" id="urgent" />
                      <Label htmlFor="urgent">Urgent (Some discomfort)</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="emergency" id="emergency" />
                      <Label htmlFor="emergency">Emergency (Severe pain)</Label>
                    </div>
                  </RadioGroup>
                </div>
              </div>

              {/* Additional Information */}
              <div>
                <Label htmlFor="message">
                  {bookingType === 'membership' ? 'Additional Information' : 'Message (Optional)'}
                </Label>
                <div className="relative mt-2">
                  <MessageSquare className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                  <Textarea
                    id="message"
                    name="message"
                    value={formData.message}
                    onChange={handleInputChange}
                    className="pl-10"
                    placeholder={
                      bookingType === 'membership' 
                        ? "Tell us about your dental history, current concerns, or any questions about the membership..."
                        : "Tell us about your dental concern or any specific requirements..."
                    }
                    rows={4}
                  />
                </div>
              </div>

              {/* Error Message */}
              {errors.submit && (
                <Alert variant="destructive">
                  <AlertDescription>{errors.submit}</AlertDescription>
                </Alert>
              )}

              {/* Emergency Note */}
              <Alert>
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>
                  <strong>Need immediate attention?</strong> For dental emergencies, 
                  please call us directly at{' '}
                  <a href="tel:01684295727" className="text-teal-600 hover:text-teal-800 underline">
                    01684 295727
                  </a>.
                </AlertDescription>
              </Alert>

              {/* Submit Button */}
              <Button 
                type="submit" 
                variant="primary"
                size="lg"
                className="w-full" 
                disabled={isSubmitting}
              >
                {isSubmitting ? (
                  <>
                    {bookingType === 'membership' ? 'Submitting Membership Request...' : 'Booking Appointment...'}
                  </>
                ) : (
                  <>
                    <Calendar className="mr-2 h-5 w-5" />
                    {bookingType === 'membership' ? 'Submit Membership Request' : 'Book Appointment'}
                  </>
                )}
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default AppointmentPage;