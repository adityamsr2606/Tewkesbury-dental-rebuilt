import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ChevronRight, Phone, ArrowLeft, Check, Calendar, Clock, User, AlertCircle } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent } from './ui/card';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Alert, AlertDescription } from './ui/alert';
import { useDataStore } from './data/dataStore';

const BookingFlow = () => {
  const navigate = useNavigate();
  const { 
    doctors, 
    treatments, 
    addBooking, 
    findPatientByPhone, 
    findPatientByEmail, 
    getAvailableDoctorsForTreatment,
    getTreatmentsByCategory 
  } = useDataStore();
  
  const [currentStep, setCurrentStep] = useState('registration');
  const [patientType, setPatientType] = useState('');
  const [selectedTreatment, setSelectedTreatment] = useState('');
  const [selectedDoctor, setSelectedDoctor] = useState('');
  const [selectedDate, setSelectedDate] = useState('');
  const [selectedTime, setSelectedTime] = useState('');
  const [validationError, setValidationError] = useState('');
  const [patientExistsError, setPatientExistsError] = useState('');
  
  const [patientData, setPatientData] = useState({
    phone: '',
    firstName: '',
    lastName: '',
    email: ''
  });

  const activeDoctors = doctors.filter(d => d.isActive);
  const activeTreatments = treatments.filter(t => t.isActive);
  
  const timeSlots = [
    '9:00 AM', '9:30 AM', '10:00 AM', '10:30 AM', '11:00 AM', '11:30 AM',
    '2:00 PM', '2:30 PM', '3:00 PM', '3:30 PM', '4:00 PM', '4:30 PM', '5:00 PM'
  ];

  // Get minimum date (tomorrow)
  const getMinDate = () => {
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    return tomorrow.toISOString().split('T')[0];
  };

  // Validation functions
  const validatePhone = (phone: string) => {
    const phoneRegex = /^\d{10}$/;
    return phoneRegex.test(phone);
  };

  const validateEmail = (email: string) => {
    return email.includes('@');
  };

  const checkPatientExists = (phone: string, email: string) => {
    const existingByPhone = findPatientByPhone(phone);
    const existingByEmail = findPatientByEmail(email);
    return existingByPhone || existingByEmail;
  };

  const handlePhoneLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setValidationError('');
    
    if (!validatePhone(patientData.phone)) {
      setValidationError('Phone number must be exactly 10 digits');
      return;
    }
    
    const existingPatient = findPatientByPhone(patientData.phone);
    if (existingPatient) {
      setPatientData(prev => ({
        ...prev,
        firstName: existingPatient.firstName,
        lastName: existingPatient.lastName,
        email: existingPatient.email
      }));
      setPatientType('existing');
      setCurrentStep('treatment-selection');
    } else {
      setValidationError('No patient found with this phone number. Please register as a new patient.');
    }
  };

  const handleNewPatientInfo = (e: React.FormEvent) => {
    e.preventDefault();
    setValidationError('');
    setPatientExistsError('');
    
    if (!validatePhone(patientData.phone)) {
      setValidationError('Phone number must be exactly 10 digits');
      return;
    }
    
    if (!validateEmail(patientData.email)) {
      setValidationError('Email must contain @');
      return;
    }
    
    if (!patientData.firstName || !patientData.lastName) {
      setValidationError('All fields are required');
      return;
    }
    
    const existingPatient = checkPatientExists(patientData.phone, patientData.email);
    if (existingPatient) {
      setPatientExistsError('Patient already exists. Please use the existing patient login option.');
      return;
    }
    
    setPatientType('new');
    setCurrentStep('treatment-selection');
  };

  const getSelectedTreatmentInfo = () => {
    return activeTreatments.find(t => t.id === selectedTreatment);
  };

  const getAvailableDoctors = () => {
    const treatmentInfo = getSelectedTreatmentInfo();
    if (!treatmentInfo) return [];
    
    return getAvailableDoctorsForTreatment(treatmentInfo.category);
  };

  const getSelectedDoctorInfo = () => {
    return activeDoctors.find(d => d.id === selectedDoctor);
  };

  const handleBookingSubmit = async () => {
    try {
      const treatmentInfo = getSelectedTreatmentInfo();
      const doctorInfo = getSelectedDoctorInfo();
      
      const bookingData = {
        firstName: patientData.firstName,
        lastName: patientData.lastName,
        email: patientData.email,
        phone: patientData.phone,
        preferredDate: selectedDate,
        preferredTime: selectedTime,
        treatmentType: treatmentInfo?.title || 'General Consultation',
        urgency: 'routine' as const,
        status: 'pending' as const,
        paymentStatus: 'pending' as const,
        message: `Booking for ${treatmentInfo?.title || 'consultation'} - ${patientType} patient`,
        doctorAssigned: doctorInfo?.name || '',
        bookingType: 'appointment' as const
      };
      
      addBooking(bookingData);
      setCurrentStep('confirmation-success');
    } catch (error) {
      console.error('Booking failed:', error);
    }
  };

  const getTreatmentCategories = () => {
    const categories = [...new Set(activeTreatments.map(t => t.category))];
    return categories;
  };

  // Registration Step
  if (currentStep === 'registration') {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-2xl w-full">
          <div className="text-center mb-12">
            <h2 className="text-4xl lg:text-5xl text-gray-800 mb-4">Tewkesbury Dental</h2>
            <p className="text-xl text-gray-600">Private Dental Care and Wellbeing</p>
          </div>

          <Card className="p-8 lg:p-12">
            <CardContent className="text-center space-y-12">
              <h1 className="text-3xl lg:text-4xl text-gray-800 leading-tight">
                Are you registered as a patient at this practice?
              </h1>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Button
                  onClick={() => setCurrentStep('existing-login')}
                  className="h-32 flex flex-col items-center justify-center space-y-2 text-xl p-6"
                  variant="outline-secondary"
                >
                  <div className="text-2xl font-bold">Yes</div>
                  <ChevronRight className="h-5 w-5" />
                  <div className="text-base text-gray-600 text-center px-2">I'm an existing patient</div>
                </Button>

                <Button
                  onClick={() => setCurrentStep('new-patient-info')}
                  className="h-32 flex flex-col items-center justify-center space-y-2 text-xl p-6"
                  variant="outline-secondary"
                >
                  <div className="text-2xl font-bold">No</div>
                  <ChevronRight className="h-5 w-5" />
                  <div className="text-base text-gray-600 text-center px-2">I'm a new patient</div>
                </Button>
              </div>

              <div className="text-center text-sm text-gray-500 space-y-2 pt-8">
                <p>Get help</p>
                <p>Terms of use</p>
                <p>Privacy Policy</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  // Existing Patient Login
  if (currentStep === 'existing-login') {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-2xl w-full">
          <div className="text-center mb-12">
            <h2 className="text-4xl lg:text-5xl text-gray-800 mb-4">Tewkesbury Dental</h2>
            <p className="text-xl text-gray-600">Private Dental Care and Wellbeing</p>
          </div>

          <Card className="p-8 lg:p-12">
            <CardContent>
              <button
                onClick={() => setCurrentStep('registration')}
                className="mb-8 text-gray-500 hover:text-gray-700 text-2xl"
              >
                ×
              </button>

              <h2 className="text-3xl lg:text-4xl text-center mb-12">Log in to your account</h2>

              {validationError && (
                <Alert className="mb-6 border-red-200 bg-red-50">
                  <AlertCircle className="h-4 w-4 text-red-600" />
                  <AlertDescription className="text-red-800">
                    {validationError}
                  </AlertDescription>
                </Alert>
              )}

              {patientData.phone && !validatePhone(patientData.phone) && (
                <Alert className="mb-6 border-red-200 bg-red-50">
                  <AlertCircle className="h-4 w-4 text-red-600" />
                  <AlertDescription className="text-red-800">
                    Phone number must be exactly 10 digits
                  </AlertDescription>
                </Alert>
              )}

              <form onSubmit={handlePhoneLogin} className="space-y-8">
                <div>
                  <Label htmlFor="phone" className="text-lg">Mobile number</Label>
                  <Input
                    id="phone"
                    type="tel"
                    value={patientData.phone}
                    onChange={(e) => {
                      setPatientData(prev => ({ ...prev, phone: e.target.value }));
                      setValidationError('');
                    }}
                    className="mt-3 h-12 text-lg"
                    maxLength={10}
                    required
                  />
                </div>

                <Button type="submit" variant="primary" size="lg" className="w-full">
                  Continue
                </Button>
              </form>

              <div className="text-center text-sm text-gray-500 mt-12 space-y-2">
                <p>Get help</p>
                <p>Terms of use</p>
                <p>Privacy Policy</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  // New Patient Info
  if (currentStep === 'new-patient-info') {
    return (
      <div className="min-h-screen bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-4xl lg:text-5xl text-gray-800 mb-4">Tewkesbury Dental</h2>
            <p className="text-xl text-gray-600">Private Dental Care and Wellbeing</p>
          </div>

          <Card className="p-8 lg:p-12">
            <CardContent>
              <button
                onClick={() => setCurrentStep('registration')}
                className="mb-8 text-gray-500 hover:text-gray-700"
              >
                <ArrowLeft className="h-6 w-6" />
              </button>

              <h2 className="text-3xl lg:text-4xl text-center mb-12">New Patient Information</h2>

              {validationError && (
                <Alert className="mb-6 border-red-200 bg-red-50">
                  <AlertCircle className="h-4 w-4 text-red-600" />
                  <AlertDescription className="text-red-800">
                    {validationError}
                  </AlertDescription>
                </Alert>
              )}

              {patientExistsError && (
                <Alert className="mb-6 border-red-200 bg-red-50">
                  <AlertCircle className="h-4 w-4 text-red-600" />
                  <AlertDescription className="text-red-800">
                    {patientExistsError}
                  </AlertDescription>
                </Alert>
              )}

              {patientData.phone && !validatePhone(patientData.phone) && (
                <Alert className="mb-6 border-red-200 bg-red-50">
                  <AlertCircle className="h-4 w-4 text-red-600" />
                  <AlertDescription className="text-red-800">
                    Phone number must be exactly 10 digits
                  </AlertDescription>
                </Alert>
              )}

              {patientData.email && !validateEmail(patientData.email) && (
                <Alert className="mb-6 border-red-200 bg-red-50">
                  <AlertCircle className="h-4 w-4 text-red-600" />
                  <AlertDescription className="text-red-800">
                    Email must contain @
                  </AlertDescription>
                </Alert>
              )}

              <form onSubmit={handleNewPatientInfo} className="space-y-8">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <Label htmlFor="firstName" className="text-lg">First Name</Label>
                    <Input
                      id="firstName"
                      value={patientData.firstName}
                      onChange={(e) => {
                        setPatientData(prev => ({ ...prev, firstName: e.target.value }));
                        setValidationError('');
                        setPatientExistsError('');
                      }}
                      className="mt-3 h-12 text-lg"
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="lastName" className="text-lg">Last Name</Label>
                    <Input
                      id="lastName"
                      value={patientData.lastName}
                      onChange={(e) => {
                        setPatientData(prev => ({ ...prev, lastName: e.target.value }));
                        setValidationError('');
                        setPatientExistsError('');
                      }}
                      className="mt-3 h-12 text-lg"
                      required
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="email" className="text-lg">Email Address</Label>
                  <Input
                    id="email"
                    type="email"
                    value={patientData.email}
                    onChange={(e) => {
                      setPatientData(prev => ({ ...prev, email: e.target.value }));
                      setValidationError('');
                      setPatientExistsError('');
                    }}
                    className="mt-3 h-12 text-lg"
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="phone" className="text-lg">Mobile Number</Label>
                  <Input
                    id="phone"
                    type="tel"
                    value={patientData.phone}
                    onChange={(e) => {
                      setPatientData(prev => ({ ...prev, phone: e.target.value }));
                      setValidationError('');
                      setPatientExistsError('');
                    }}
                    className="mt-3 h-12 text-lg"
                    maxLength={10}
                    required
                  />
                </div>

                <Button type="submit" variant="primary" size="lg" className="w-full">
                  Continue
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  // Treatment Selection
  if (currentStep === 'treatment-selection') {
    return (
      <div className="min-h-screen bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-4xl lg:text-5xl text-gray-800 mb-4">Tewkesbury Dental</h2>
            <p className="text-xl text-gray-600">Private Dental Care and Wellbeing</p>
          </div>

          <Card className="p-8 lg:p-12">
            <CardContent className="space-y-8">
              <button
                onClick={() => setCurrentStep(patientType === 'existing' ? 'existing-login' : 'new-patient-info')}
                className="text-gray-500 hover:text-gray-700"
              >
                <ArrowLeft className="h-6 w-6" />
              </button>

              <h2 className="text-3xl lg:text-4xl text-center">Select Treatment</h2>
              <p className="text-center text-gray-600">Choose the treatment you would like to book</p>

              <div className="space-y-6">
                {getTreatmentCategories().map(category => (
                  <div key={category}>
                    <h3 className="text-xl font-semibold mb-4 text-gray-800">{category}</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {getTreatmentsByCategory(category).map(treatment => (
                        <Button
                          key={treatment.id}
                          onClick={() => {
                            setSelectedTreatment(treatment.id);
                            setCurrentStep('choose-practitioner');
                          }}
                          className="h-auto p-6 flex flex-col items-start space-y-3 text-left"
                          variant="outline-secondary"
                        >
                          <div className="flex items-center justify-between w-full">
                            <h4 className="text-lg font-semibold">{treatment.title}</h4>
                            <span className="text-lg font-bold text-teal-600">{treatment.price}</span>
                          </div>
                          <div className="flex items-center justify-between w-full">
                            <span className="text-sm text-gray-500">Duration: {treatment.duration}</span>
                            <ChevronRight className="h-5 w-5" />
                          </div>
                        </Button>
                      ))}
                    </div>
                  </div>
                ))}
              </div>

              <div className="pt-8 border-t">
                <Button
                  onClick={() => setCurrentStep('contact-info')}
                  variant="outline-secondary"
                  className="w-full h-16 text-xl"
                >
                  Need something else? Contact us directly
                  <ChevronRight className="h-6 w-6 ml-2" />
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  // Contact Info for "Something Else"
  if (currentStep === 'contact-info') {
    return (
      <div className="min-h-screen bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-4xl lg:text-5xl text-gray-800 mb-4">Tewkesbury Dental</h2>
            <p className="text-xl text-gray-600">Private Dental Care and Wellbeing</p>
          </div>

          <Card className="p-8 lg:p-12">
            <CardContent className="space-y-8">
              <button
                onClick={() => setCurrentStep('treatment-selection')}
                className="text-gray-500 hover:text-gray-700"
              >
                <ArrowLeft className="h-6 w-6" />
              </button>

              <h2 className="text-3xl lg:text-4xl text-center mb-8">Contact Information</h2>

              <div className="space-y-6">
                <div className="bg-blue-50 p-6 rounded-lg">
                  <h3 className="text-xl mb-4">Clinic Contact</h3>
                  <div className="space-y-4">
                    <div className="flex items-center space-x-3">
                      <Phone className="h-5 w-5 text-teal-600" />
                      <a href="tel:01684295727" className="text-xl text-teal-600 hover:text-teal-800">
                        01684 295727
                      </a>
                    </div>
                    <p className="text-gray-600">
                      Call us directly for emergency appointments, specific treatments, or any questions.
                    </p>
                  </div>
                </div>

                <div className="bg-gray-50 p-6 rounded-lg">
                  <h3 className="text-xl mb-4">Available Doctors</h3>
                  <div className="space-y-3">
                    {activeDoctors.map(doctor => (
                      <div key={doctor.id} className="flex items-center space-x-3">
                        <User className="h-5 w-5 text-gray-500" />
                        <span>{doctor.name} - {doctor.position}</span>
                      </div>
                    ))}
                  </div>
                  <p className="text-gray-600 mt-3">
                    Our experienced team is ready to help with your dental needs.
                  </p>
                </div>
              </div>

              <Button
                onClick={() => navigate('/')}
                variant="outline-secondary"
                className="w-full h-12 text-lg"
              >
                Return to Homepage
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  // Choose Practitioner
  if (currentStep === 'choose-practitioner') {
    const availableDoctors = getAvailableDoctors();
    const treatmentInfo = getSelectedTreatmentInfo();

    return (
      <div className="min-h-screen bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-4xl lg:text-5xl text-gray-800 mb-4">Tewkesbury Dental</h2>
            <p className="text-xl text-gray-600">Private Dental Care and Wellbeing</p>
          </div>

          <Card className="p-8 lg:p-12">
            <CardContent className="space-y-8">
              <button
                onClick={() => setCurrentStep('treatment-selection')}
                className="text-gray-500 hover:text-gray-700"
              >
                <ArrowLeft className="h-6 w-6" />
              </button>

              <div className="text-center">
                <h2 className="text-3xl lg:text-4xl mb-4">Choose Practitioner</h2>
                <p className="text-xl text-gray-600">
                  For {treatmentInfo?.title} - {treatmentInfo?.price}
                </p>
              </div>

              {availableDoctors.length === 0 ? (
                <div className="text-center py-12">
                  <p className="text-xl text-gray-600 mb-6">
                    No practitioners available for this treatment at the moment.
                  </p>
                  <Button
                    onClick={() => setCurrentStep('contact-info')}
                    variant="primary"
                  >
                    Contact us directly
                  </Button>
                </div>
              ) : (
                <div className="space-y-6">
                  {availableDoctors.map(doctor => (
                    <Button
                      key={doctor.id}
                      onClick={() => {
                        setSelectedDoctor(doctor.id);
                        setCurrentStep('choose-datetime');
                      }}
                      className="w-full p-6 h-auto flex items-start space-x-6 text-left"
                      variant="outline-secondary"
                    >
                      <img
                        src={doctor.image}
                        alt={doctor.name}
                        className="w-20 h-20 rounded-full object-cover flex-shrink-0"
                      />
                      <div className="flex-1 min-w-0">
                        <h3 className="text-xl mb-2">{doctor.name}</h3>
                        <p className="text-gray-600 mb-1">{doctor.position}</p>
                        <p className="text-gray-500 mb-3">{doctor.qualifications}</p>
                        <div className="flex flex-wrap gap-2">
                          {doctor.specializations.slice(0, 3).map(spec => (
                            <span key={spec} className="text-sm bg-gray-200 px-3 py-1 rounded">
                              {spec}
                            </span>
                          ))}
                        </div>
                      </div>
                      <ChevronRight className="h-6 w-6 mt-2 flex-shrink-0" />
                    </Button>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  // Choose Date and Time
  if (currentStep === 'choose-datetime') {
    const doctorInfo = getSelectedDoctorInfo();
    const treatmentInfo = getSelectedTreatmentInfo();
    
    return (
      <div className="min-h-screen bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-4xl lg:text-5xl text-gray-800 mb-4">Tewkesbury Dental</h2>
            <p className="text-xl text-gray-600">Private Dental Care and Wellbeing</p>
          </div>

          <Card className="p-8 lg:p-12">
            <CardContent className="space-y-8">
              <button
                onClick={() => setCurrentStep('choose-practitioner')}
                className="text-gray-500 hover:text-gray-700"
              >
                <ArrowLeft className="h-6 w-6" />
              </button>

              <div className="text-center">
                <h2 className="text-3xl lg:text-4xl mb-4">Choose Date & Time</h2>
                <p className="text-xl text-gray-600">
                  {treatmentInfo?.title} with {doctorInfo?.name}
                </p>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
                <div>
                  <Label htmlFor="date" className="text-xl mb-6 block">Select Date</Label>
                  <Input
                    id="date"
                    type="date"
                    min={getMinDate()}
                    value={selectedDate}
                    onChange={(e) => setSelectedDate(e.target.value)}
                    className="text-lg p-4 h-14"
                  />
                </div>

                <div>
                  <Label className="text-xl mb-6 block">Available Times</Label>
                  <div className="grid grid-cols-2 gap-3 max-h-96 overflow-y-auto">
                    {timeSlots.map(time => (
                      <Button
                        key={time}
                        onClick={() => setSelectedTime(time)}
                        variant={selectedTime === time ? "primary" : "outline-secondary"}
                        className="p-4 h-12 text-lg"
                      >
                        {time}
                      </Button>
                    ))}
                  </div>
                </div>
              </div>

              {selectedDate && selectedTime && (
                <div className="bg-green-50 p-6 rounded-lg">
                  <div className="flex items-center space-x-3">
                    <Check className="h-6 w-6 text-green-600" />
                    <span className="text-green-800 text-lg">
                      Selected: {new Date(selectedDate).toLocaleDateString('en-GB')} at {selectedTime}
                    </span>
                  </div>
                </div>
              )}

              <Button
                onClick={() => setCurrentStep('confirmation')}
                disabled={!selectedDate || !selectedTime}
                className="w-full h-14 text-lg bg-teal-600 hover:bg-teal-700"
              >
                Continue to Confirmation
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  // Confirmation Page
  if (currentStep === 'confirmation') {
    const doctorInfo = getSelectedDoctorInfo();
    const treatmentInfo = getSelectedTreatmentInfo();
    
    return (
      <div className="min-h-screen bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-4xl lg:text-5xl text-gray-800 mb-4">Tewkesbury Dental</h2>
            <p className="text-xl text-gray-600">Private Dental Care and Wellbeing</p>
          </div>

          <Card className="p-8 lg:p-12">
            <CardContent className="space-y-8">
              <button
                onClick={() => setCurrentStep('choose-datetime')}
                className="text-gray-500 hover:text-gray-700"
              >
                <ArrowLeft className="h-6 w-6" />
              </button>

              <h2 className="text-3xl lg:text-4xl text-center mb-8">Confirm Your Appointment</h2>

              <div className="space-y-6">
                <div className="bg-white border rounded-lg p-6">
                  <h3 className="text-xl mb-6">Patient Information</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <span className="text-gray-600">Name:</span>
                      <p className="text-lg">{patientData.firstName} {patientData.lastName}</p>
                    </div>
                    <div>
                      <span className="text-gray-600">Email:</span>
                      <p className="text-lg">{patientData.email}</p>
                    </div>
                    <div>
                      <span className="text-gray-600">Phone:</span>
                      <p className="text-lg">{patientData.phone}</p>
                    </div>
                    <div>
                      <span className="text-gray-600">Patient Type:</span>
                      <p className="text-lg capitalize">{patientType}</p>
                    </div>
                  </div>
                </div>

                <div className="bg-white border rounded-lg p-6">
                  <h3 className="text-xl mb-6">Treatment Details</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <span className="text-gray-600">Treatment:</span>
                      <p className="text-lg">{treatmentInfo?.title}</p>
                    </div>
                    <div>
                      <span className="text-gray-600">Category:</span>
                      <p className="text-lg">{treatmentInfo?.category}</p>
                    </div>
                    <div>
                      <span className="text-gray-600">Duration:</span>
                      <p className="text-lg">{treatmentInfo?.duration}</p>
                    </div>
                    <div>
                      <span className="text-gray-600">Cost:</span>
                      <p className="text-lg font-semibold text-teal-600">{treatmentInfo?.price}</p>
                    </div>
                  </div>
                </div>

                <div className="bg-white border rounded-lg p-6">
                  <h3 className="text-xl mb-6">Appointment Details</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <span className="text-gray-600">Date:</span>
                      <p className="text-lg">{new Date(selectedDate).toLocaleDateString('en-GB')}</p>
                    </div>
                    <div>
                      <span className="text-gray-600">Time:</span>
                      <p className="text-lg">{selectedTime}</p>
                    </div>
                  </div>
                </div>

                {doctorInfo && (
                  <div className="bg-white border rounded-lg p-6">
                    <h3 className="text-xl mb-6">Your Practitioner</h3>
                    <div className="flex items-start space-x-6">
                      <img
                        src={doctorInfo.image}
                        alt={doctorInfo.name}
                        className="w-20 h-20 rounded-full object-cover"
                      />
                      <div>
                        <h4 className="text-xl">{doctorInfo.name}</h4>
                        <p className="text-gray-600 mb-2">{doctorInfo.position}</p>
                        <p className="text-gray-500">{doctorInfo.qualifications}</p>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              <Button
                onClick={handleBookingSubmit}
                className="w-full bg-teal-600 hover:bg-teal-700 h-14 text-xl"
              >
                Book Appointment
              </Button>

              <p className="text-sm text-gray-500 text-center">
                By booking this appointment, you agree to our terms and conditions.
                Payment will be taken at the practice after your appointment.
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  // Success Page
  if (currentStep === 'confirmation-success') {
    const treatmentInfo = getSelectedTreatmentInfo();
    const doctorInfo = getSelectedDoctorInfo();
    
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-2xl w-full">
          <div className="text-center mb-12">
            <h2 className="text-4xl lg:text-5xl text-gray-800 mb-4">Tewkesbury Dental</h2>
            <p className="text-xl text-gray-600">Private Dental Care and Wellbeing</p>
          </div>

          <Card className="p-8 lg:p-12">
            <CardContent className="text-center space-y-8">
              <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto">
                <Check className="h-10 w-10 text-green-600" />
              </div>

              <h1 className="text-3xl lg:text-4xl text-gray-800">
                Booking Confirmed!
              </h1>

              <div className="bg-green-50 border border-green-200 rounded-lg p-6">
                <h3 className="text-lg font-semibold text-green-800 mb-4">Your Appointment Details</h3>
                <div className="text-left space-y-2">
                  <p><strong>Treatment:</strong> {treatmentInfo?.title}</p>
                  <p><strong>Date:</strong> {new Date(selectedDate).toLocaleDateString('en-GB')}</p>
                  <p><strong>Time:</strong> {selectedTime}</p>
                  <p><strong>Doctor:</strong> {doctorInfo?.name}</p>
                  <p><strong>Cost:</strong> {treatmentInfo?.price}</p>
                </div>
              </div>

              <p className="text-gray-600">
                A confirmation email will be sent to {patientData.email}. 
                Please arrive 10 minutes before your appointment time.
              </p>

              <div className="space-y-4">
                <Button
                  onClick={() => navigate('/')}
                  className="w-full h-12 text-lg bg-teal-600 hover:bg-teal-700"
                >
                  Return to Homepage
                </Button>
                
                <div className="text-center">
                  <p className="text-sm text-gray-500">Need to reschedule?</p>
                  <a href="tel:01684295727" className="text-teal-600 hover:text-teal-800">
                    Call us at 01684 295727
                  </a>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return null;
};

export default BookingFlow;