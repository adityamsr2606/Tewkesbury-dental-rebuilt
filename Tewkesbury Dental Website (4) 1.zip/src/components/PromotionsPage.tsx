import React from "react";
import { Link } from "react-router-dom";
import { Calendar, Clock, Shield, Award } from "lucide-react";
import { Button } from "./ui/button";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "./ui/card";
import { Badge } from "./ui/badge";

const PromotionsPage = () => {
  const promotions = [
    {
      id: 1,
      title: "New Patient Offer",
      discount: "20%",
      description:
        "Complete dental examination including X-rays and consultation for new patients.",
      originalPrice: "£85",
      salePrice: "£68",
      validUntil: "31st March 2024",
      terms:
        "Valid for new patients only. Cannot be combined with other offers.",
      featured: true,
    },
    {
      id: 2,
      title: "Teeth Whitening Special",
      discount: "15%",
      description:
        "Professional teeth whitening treatment to brighten your smile.",
      originalPrice: "£350",
      salePrice: "£297.50",
      validUntil: "30th April 2024",
      terms:
        "Includes consultation and take-home maintenance kit.",
      featured: false,
    },
    {
      id: 3,
      title: "Family Dental Package",
      discount: "25%",
      description:
        "Comprehensive dental care for the whole family (4+ members).",
      originalPrice: "£300",
      salePrice: "£225",
      validUntil: "31st May 2024",
      terms:
        "Valid for families with 4 or more members. Includes checkups and cleanings.",
      featured: false,
    },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-r from-blue-600 to-teal-600 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl lg:text-6xl mb-6">
              Special Offers
            </h1>
            <p className="text-xl lg:text-2xl text-blue-100 max-w-3xl mx-auto">
              Take advantage of our limited-time promotions and
              dental membership plans designed to make quality
              dental care more affordable.
            </p>
          </div>
        </div>
      </section>

      {/* Current Promotions */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl lg:text-4xl mb-4">
              Limited Time Offers
            </h2>
            <p className="text-xl text-gray-600">
              Special discounts on our most popular dental
              treatments.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {promotions.map((promo) => (
              <Card
                key={promo.id}
                className={`flex flex-col overflow-hidden hover:shadow-lg transition-shadow duration-300 h-full ${promo.featured ? "ring-2 ring-teal-600" : ""}`}
              >
                {promo.featured && (
                  <div className="bg-teal-600 text-white text-center py-2 flex-shrink-0">
                    <Badge className="bg-yellow-500 text-yellow-900">
                      Most Popular
                    </Badge>
                  </div>
                )}

                <CardHeader className="flex-shrink-0">
                  <div className="flex justify-between items-start">
                    <CardTitle className="text-xl">
                      {promo.title}
                    </CardTitle>
                    <Badge
                      variant="secondary"
                      className="text-lg px-3 py-1"
                    >
                      {promo.discount} OFF
                    </Badge>
                  </div>
                </CardHeader>

                <CardContent className="flex flex-col flex-1 space-y-4">
                  <p className="text-gray-600 flex-1">
                    {promo.description}
                  </p>

                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-gray-500 line-through">
                        Was: {promo.originalPrice}
                      </span>
                      <span className="text-2xl text-teal-600">
                        {promo.salePrice}
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center text-sm text-gray-600">
                    <Calendar className="h-4 w-4 mr-1" />
                    Valid until {promo.validUntil}
                  </div>

                  <p className="text-xs text-gray-500">
                    {promo.terms}
                  </p>

                  <div className="mt-auto pt-4">
                    <Link to="/book" className="block">
                      <Button className="w-full">
                        Book This Offer
                      </Button>
                    </Link>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Dental Membership */}
      <section className="bg-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl lg:text-4xl mb-4">
              Dental Membership Plan
            </h2>
            <p className="text-xl text-gray-600">
              Affordable dental care with no insurance hassles.
              Perfect for individuals and families.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-6">
              <h3 className="text-2xl">
                Why Choose Our Membership Plan?
              </h3>

              <div className="space-y-4">
                <div className="flex items-start space-x-3">
                  <Shield className="h-6 w-6 text-teal-600 mt-1" />
                  <div>
                    <h4 className="text-lg">
                      No Insurance Required
                    </h4>
                    <p className="text-gray-600">
                      Direct relationship with your dental care
                      team without insurance limitations.
                    </p>
                  </div>
                </div>

                <div className="flex items-start space-x-3">
                  <Award className="h-6 w-6 text-teal-600 mt-1" />
                  <div>
                    <h4 className="text-lg">
                      Preventive Focus
                    </h4>
                    <p className="text-gray-600">
                      Regular checkups and cleanings to prevent
                      costly dental problems.
                    </p>
                  </div>
                </div>

                <div className="flex items-start space-x-3">
                  <Clock className="h-6 w-6 text-teal-600 mt-1" />
                  <div>
                    <h4 className="text-lg">
                      Convenient Scheduling
                    </h4>
                    <p className="text-gray-600">
                      Priority booking and flexible appointment
                      times for members.
                    </p>
                  </div>
                </div>
              </div>

              <div className="flex flex-col sm:flex-row gap-4">
                <Link to="/contact">
                  <Button
                    size="lg"
                    variant="outline"
                    className="w-full sm:w-auto"
                  >
                    Learn More
                  </Button>
                </Link>
                <Link to="/book">
                </Link>
              </div>
            </div>

            <Card className="p-8">
              <CardHeader className="text-center pb-6">
                <CardTitle className="text-2xl">
                  Membership Benefits
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="text-center mb-6">
                  <div className="text-4xl text-teal-600 mb-2">
                    £29
                  </div>
                  <div className="text-gray-600">per month</div>
                </div>

                <ul className="space-y-3">
                  <li className="flex items-center">
                    <div className="w-2 h-2 bg-teal-600 rounded-full mr-3"></div>
                    2 dental examinations per year
                  </li>
                  <li className="flex items-center">
                    <div className="w-2 h-2 bg-teal-600 rounded-full mr-3"></div>
                    2 professional cleanings per year
                  </li>
                  <li className="flex items-center">
                    <div className="w-2 h-2 bg-teal-600 rounded-full mr-3"></div>
                    20% discount on all treatments
                  </li>
                  <li className="flex items-center">
                    <div className="w-2 h-2 bg-teal-600 rounded-full mr-3"></div>
                    Emergency dental care included
                  </li>
                  <li className="flex items-center">
                    <div className="w-2 h-2 bg-teal-600 rounded-full mr-3"></div>
                    No annual limits or deductibles
                  </li>
                  <li className="flex items-center">
                    <div className="w-2 h-2 bg-teal-600 rounded-full mr-3"></div>
                    Family discounts available
                  </li>
                </ul>

                <div className="text-center pt-4">
                  <Link to="/book">
                     <Button
                    size="lg"
                    variant="outline"
                    className="w-full sm:w-auto"
                  >
                    Learn More
                  </Button>
                    
              
                    
                  </Link>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Terms and Conditions */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <Card>
            <CardHeader>
              <CardTitle>
                Promotion Terms & Conditions
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h4 className="mb-3">General Terms</h4>
                  <ul className="space-y-2 text-sm text-gray-600">
                    <li>
                      • Offers valid for new and existing
                      patients
                    </li>
                    <li>
                      • Cannot be combined with other promotions
                    </li>
                    <li>
                      • Appointments must be booked by the
                      expiry date
                    </li>
                    <li>
                      • Valid ID required for all promotional
                      offers
                    </li>
                    <li>
                      • Management reserves the right to modify
                      terms
                    </li>
                  </ul>
                </div>
                <div>
                  <h4 className="mb-3">Membership Plan</h4>
                  <ul className="space-y-2 text-sm text-gray-600">
                    <li>
                      • 12-month minimum commitment required
                    </li>
                    <li>• Monthly payments by direct debit</li>
                    <li>
                      • 30-day notice required for cancellation
                    </li>
                    <li>
                      • Transferable between family members
                    </li>
                    <li>• Emergency coverage 24/7</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Contact CTA */}
      <section className="bg-teal-600 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl lg:text-4xl mb-4">
            Questions About Our Offers?
          </h2>
          <p className="text-xl mb-8 text-teal-100">
            Our friendly team is here to help you choose the
            best option for your dental needs.
          </p>
          <Link to="/contact">
            <Button
              size="lg" className="bg-black text-teal-600:bg-gray-100">
              Contact Us
            </Button>
          </Link>
        </div>
      </section>
    </div>
  );
};

export default PromotionsPage;