import React, { useState, useRef } from 'react';
import { 
  Calendar, Users, CreditCard, Search, Filter, 
  Edit, Trash2, Eye, Phone, Mail, CheckCircle, XCircle,
  Plus, Download, BarChart3, TrendingUp, Upload, UserPlus,
  Stethoscope, Star, Clock, MapPin, AlertTriangle
} from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Badge } from './ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from './ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Textarea } from './ui/textarea';
import { Alert, AlertDescription } from './ui/alert';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from './ui/alert-dialog';
import { useDataStore, Doctor, Booking, Treatment, Review } from './data/dataStore';

const AdminDashboard = () => {
  const {
    doctors, bookings, treatments, reviews,
    addDoctor, updateDoctor, deleteDoctor,
    updateBooking, deleteBooking,
    addTreatment, updateTreatment, deleteTreatment,
    updateReview, deleteReview
  } = useDataStore();

  const [activeTab, setActiveTab] = useState('dashboard');
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');
  const [selectedItem, setSelectedItem] = useState(null);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [editingItem, setEditingItem] = useState(null);
  const [editingType, setEditingType] = useState('');
  const [deleteDialog, setDeleteDialog] = useState({ open: false, item: null, type: '' });
  const fileInputRef = useRef(null);

  // Scroll to top when tab changes
  React.useEffect(() => {
    window.scrollTo(0, 0);
  }, [activeTab]);

  const stats = {
    totalBookings: bookings.length,
    pendingBookings: bookings.filter(b => b.status === 'pending').length,
    membershipBookings: bookings.filter(b => b.bookingType === 'membership').length,
    totalDoctors: doctors.filter(d => d.isActive).length,
    totalTreatments: treatments.filter(t => t.isActive).length,
    totalReviews: reviews.length
  };

  const handleImageUpload = (event) => {
    const file = event.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        if (editingType === 'doctor') {
          setEditingItem(prev => ({ ...prev, image: e.target.result }));
        } else if (editingType === 'treatment') {
          setEditingItem(prev => ({ ...prev, image: e.target.result }));
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleAdd = (type) => {
    const newItem = getEmptyItem(type);
    setEditingItem(newItem);
    setEditingType(type);
    setIsEditDialogOpen(true);
  };

  const handleEdit = (item, type) => {
    setEditingItem({ ...item });
    setEditingType(type);
    setIsEditDialogOpen(true);
  };

  const handleSave = () => {
    if (!editingItem || !editingType) return;

    if (editingItem.id && editingItem.id !== 'new') {
      // Update existing item
      switch (editingType) {
        case 'doctor':
          updateDoctor(editingItem.id, editingItem);
          break;
        case 'booking':
          updateBooking(editingItem.id, editingItem);
          break;
        case 'treatment':
          updateTreatment(editingItem.id, editingItem);
          break;
        case 'review':
          updateReview(editingItem.id, editingItem);
          break;
      }
    } else {
      // Add new item
      const { id, ...itemWithoutId } = editingItem;
      switch (editingType) {
        case 'doctor':
          addDoctor(itemWithoutId);
          break;
        case 'treatment':
          addTreatment(itemWithoutId);
          break;
      }
    }

    setIsEditDialogOpen(false);
    setEditingItem(null);
    setEditingType('');
  };

  const openDeleteDialog = (item, type) => {
    setDeleteDialog({ open: true, item, type });
  };

  const handleDelete = () => {
    const { item, type } = deleteDialog;
    switch (type) {
      case 'doctor':
        deleteDoctor(item.id);
        break;
      case 'booking':
        deleteBooking(item.id);
        break;
      case 'treatment':
        deleteTreatment(item.id);
        break;
      case 'review':
        deleteReview(item.id);
        break;
    }
    setDeleteDialog({ open: false, item: null, type: '' });
  };

  const getEmptyItem = (type) => {
    switch (type) {
      case 'doctor':
        return {
          id: 'new',
          name: '',
          position: '',
          qualifications: '',
          bio: '',
          image: '',
          specializations: [],
          yearsOfExperience: 0,
          email: '',
          phone: '',
          isActive: true
        };
      case 'treatment':
        return {
          id: 'new',
          title: '',
          description: '',
          image: '',
          duration: '',
          price: '',
          services: [],
          category: '',
          isActive: true
        };
      default:
        return {};
    }
  };

  const NoDataMessage = ({ type }) => (
    <div className="text-center py-12">
      <div className="text-gray-400 mb-4">
        <AlertTriangle className="h-12 w-12 mx-auto" />
      </div>
      <h3 className="text-lg font-medium text-gray-900 mb-2">No {type} Available</h3>
      <p className="text-gray-500">There are currently no {type.toLowerCase()} in the system.</p>
    </div>
  );

  const DashboardStats = () => (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-6 mb-8">
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm">Total Bookings</CardTitle>
          <Calendar className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl">{stats.totalBookings}</div>
          <p className="text-xs text-muted-foreground">All appointments</p>
        </CardContent>
      </Card>
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm">Pending</CardTitle>
          <AlertTriangle className="h-4 w-4 text-yellow-500" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl">{stats.pendingBookings}</div>
          <p className="text-xs text-muted-foreground">Awaiting confirmation</p>
        </CardContent>
      </Card>
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm">Memberships</CardTitle>
          <Users className="h-4 w-4 text-blue-500" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl">{stats.membershipBookings}</div>
          <p className="text-xs text-muted-foreground">Membership requests</p>
        </CardContent>
      </Card>
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm">Doctors</CardTitle>
          <Stethoscope className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl">{stats.totalDoctors}</div>
          <p className="text-xs text-muted-foreground">Active practitioners</p>
        </CardContent>
      </Card>
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm">Treatments</CardTitle>
          <CreditCard className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl">{stats.totalTreatments}</div>
          <p className="text-xs text-muted-foreground">Available services</p>
        </CardContent>
      </Card>
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm">Reviews</CardTitle>
          <Star className="h-4 w-4 text-yellow-500" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl">{stats.totalReviews}</div>
          <p className="text-xs text-muted-foreground">Total reviews</p>
        </CardContent>
      </Card>
    </div>
  );

  const renderEditDialog = () => {
    if (!editingItem || !editingType) return null;

    return (
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="max-w-6xl max-h-[95vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-2xl">
              {editingItem.id === 'new' ? 'Add New' : 'Edit'} {editingType.charAt(0).toUpperCase() + editingType.slice(1)}
            </DialogTitle>
            <DialogDescription>
              {editingItem.id === 'new' 
                ? `Fill in the form below to add a new ${editingType}.` 
                : `Make changes to the ${editingType} information below.`
              }
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-8 p-2">
            {editingType === 'doctor' && (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <div className="space-y-6">
                  <div>
                    <Label className="text-base">Name *</Label>
                    <Input
                      value={editingItem.name}
                      onChange={(e) => setEditingItem(prev => ({ ...prev, name: e.target.value }))}
                      placeholder="Doctor's full name"
                      className="mt-2 h-12"
                    />
                  </div>
                  <div>
                    <Label className="text-base">Position *</Label>
                    <Input
                      value={editingItem.position}
                      onChange={(e) => setEditingItem(prev => ({ ...prev, position: e.target.value }))}
                      placeholder="e.g. Principal Dentist"
                      className="mt-2 h-12"
                    />
                  </div>
                  <div>
                    <Label className="text-base">Qualifications *</Label>
                    <Input
                      value={editingItem.qualifications}
                      onChange={(e) => setEditingItem(prev => ({ ...prev, qualifications: e.target.value }))}
                      placeholder="e.g. BDS (Hons), MFDS RCS (Ed)"
                      className="mt-2 h-12"
                    />
                  </div>
                  <div>
                    <Label className="text-base">Email *</Label>
                    <Input
                      type="email"
                      value={editingItem.email}
                      onChange={(e) => setEditingItem(prev => ({ ...prev, email: e.target.value }))}
                      placeholder="doctor@tewkesburydental.co.uk"
                      className="mt-2 h-12"
                    />
                  </div>
                  <div>
                    <Label className="text-base">Phone *</Label>
                    <Input
                      value={editingItem.phone}
                      onChange={(e) => setEditingItem(prev => ({ ...prev, phone: e.target.value }))}
                      placeholder="01684 295727"
                      className="mt-2 h-12"
                    />
                  </div>
                  <div>
                    <Label className="text-base">Years of Experience</Label>
                    <Input
                      type="number"
                      value={editingItem.yearsOfExperience}
                      onChange={(e) => setEditingItem(prev => ({ ...prev, yearsOfExperience: parseInt(e.target.value) || 0 }))}
                      className="mt-2 h-12"
                    />
                  </div>
                </div>
                <div className="space-y-6">
                  <div>
                    <Label className="text-base">Photo</Label>
                    <div className="space-y-4 mt-2">
                      {editingItem.image && (
                        <img 
                          src={editingItem.image} 
                          alt="Doctor" 
                          className="w-48 h-48 object-cover rounded-lg mx-auto"
                        />
                      )}
                      <Button
                        type="button"
                        variant="outline"
                        onClick={() => fileInputRef.current?.click()}
                        className="w-full h-12"
                      >
                        <Upload className="mr-2 h-5 w-5" />
                        Upload Photo
                      </Button>
                      <input
                        ref={fileInputRef}
                        type="file"
                        accept="image/*"
                        onChange={handleImageUpload}
                        className="hidden"
                      />
                    </div>
                  </div>
                  <div>
                    <Label className="text-base">Specializations</Label>
                    <Input
                      value={editingItem.specializations?.join(', ') || ''}
                      onChange={(e) => setEditingItem(prev => ({ 
                        ...prev, 
                        specializations: e.target.value.split(',').map(s => s.trim()).filter(s => s)
                      }))}
                      placeholder="Cosmetic Dentistry, Implants, etc."
                      className="mt-2 h-12"
                    />
                  </div>
                  <div>
                    <Label className="text-base">Biography *</Label>
                    <Textarea
                      value={editingItem.bio}
                      onChange={(e) => setEditingItem(prev => ({ ...prev, bio: e.target.value }))}
                      placeholder="Brief professional biography..."
                      rows={8}
                      className="mt-2"
                    />
                  </div>
                  <div className="flex items-center space-x-3">
                    <input
                      type="checkbox"
                      id="isActive"
                      checked={editingItem.isActive}
                      onChange={(e) => setEditingItem(prev => ({ ...prev, isActive: e.target.checked }))}
                      className="w-5 h-5"
                    />
                    <Label htmlFor="isActive" className="text-base">Active (visible on website)</Label>
                  </div>
                </div>
              </div>
            )}

            {editingType === 'treatment' && (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <div className="space-y-6">
                  <div>
                    <Label className="text-base">Title *</Label>
                    <Input
                      value={editingItem.title}
                      onChange={(e) => setEditingItem(prev => ({ ...prev, title: e.target.value }))}
                      placeholder="Treatment name"
                      className="mt-2 h-12"
                    />
                  </div>
                  <div>
                    <Label className="text-base">Category *</Label>
                    <Select
                      value={editingItem.category}
                      onValueChange={(value) => setEditingItem(prev => ({ ...prev, category: value }))}
                    >
                      <SelectTrigger className="mt-2 h-12">
                        <SelectValue placeholder="Select category" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="General Dentistry">General Dentistry</SelectItem>
                        <SelectItem value="Cosmetic Dentistry">Cosmetic Dentistry</SelectItem>
                        <SelectItem value="Restorative Dentistry">Restorative Dentistry</SelectItem>
                        <SelectItem value="Oral Surgery">Oral Surgery</SelectItem>
                        <SelectItem value="Facial Aesthetics">Facial Aesthetics</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label className="text-base">Price *</Label>
                    <Input
                      value={editingItem.price}
                      onChange={(e) => setEditingItem(prev => ({ ...prev, price: e.target.value }))}
                      placeholder="£65"
                      className="mt-2 h-12"
                    />
                  </div>
                  <div>
                    <Label className="text-base">Duration *</Label>
                    <Input
                      value={editingItem.duration}
                      onChange={(e) => setEditingItem(prev => ({ ...prev, duration: e.target.value }))}
                      placeholder="30 minutes"
                      className="mt-2 h-12"
                    />
                  </div>
                  <div>
                    <Label className="text-base">Services Included</Label>
                    <Textarea
                      value={editingItem.services?.join(', ') || ''}
                      onChange={(e) => setEditingItem(prev => ({ 
                        ...prev, 
                        services: e.target.value.split(',').map(s => s.trim()).filter(s => s)
                      }))}
                      placeholder="Service 1, Service 2, Service 3"
                      rows={4}
                      className="mt-2"
                    />
                  </div>
                </div>
                <div className="space-y-6">
                  <div>
                    <Label className="text-base">Treatment Image</Label>
                    <div className="space-y-4 mt-2">
                      {editingItem.image && (
                        <img 
                          src={editingItem.image} 
                          alt="Treatment" 
                          className="w-48 h-48 object-cover rounded-lg mx-auto"
                        />
                      )}
                      <Button
                        type="button"
                        variant="outline"
                        onClick={() => fileInputRef.current?.click()}
                        className="w-full h-12"
                      >
                        <Upload className="mr-2 h-5 w-5" />
                        Upload Image
                      </Button>
                    </div>
                  </div>
                  <div>
                    <Label className="text-base">Description *</Label>
                    <Textarea
                      value={editingItem.description}
                      onChange={(e) => setEditingItem(prev => ({ ...prev, description: e.target.value }))}
                      placeholder="Detailed treatment description..."
                      rows={8}
                      className="mt-2"
                    />
                  </div>
                  <div className="flex items-center space-x-3">
                    <input
                      type="checkbox"
                      id="treatmentActive"
                      checked={editingItem.isActive}
                      onChange={(e) => setEditingItem(prev => ({ ...prev, isActive: e.target.checked }))}
                      className="w-5 h-5"
                    />
                    <Label htmlFor="treatmentActive" className="text-base">Active (visible on website)</Label>
                  </div>
                </div>
              </div>
            )}

            {editingType === 'booking' && (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <div className="space-y-6">
                  <div>
                    <Label className="text-base">Status</Label>
                    <Select
                      value={editingItem.status}
                      onValueChange={(value) => setEditingItem(prev => ({ ...prev, status: value }))}
                    >
                      <SelectTrigger className="mt-2 h-12">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="pending">Pending</SelectItem>
                        <SelectItem value="confirmed">Confirmed</SelectItem>
                        <SelectItem value="completed">Completed</SelectItem>
                        <SelectItem value="cancelled">Cancelled</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label className="text-base">Doctor Assigned</Label>
                    <Select
                      value={editingItem.doctorAssigned || ''}
                      onValueChange={(value) => setEditingItem(prev => ({ ...prev, doctorAssigned: value }))}
                    >
                      <SelectTrigger className="mt-2 h-12">
                        <SelectValue placeholder="Assign doctor" />
                      </SelectTrigger>
                      <SelectContent>
                        {doctors.filter(d => d.isActive).map(doctor => (
                          <SelectItem key={doctor.id} value={doctor.name}>
                            {doctor.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="space-y-6">
                  <div>
                    <Label className="text-base">Payment Status</Label>
                    <Select
                      value={editingItem.paymentStatus}
                      onValueChange={(value) => setEditingItem(prev => ({ ...prev, paymentStatus: value }))}
                    >
                      <SelectTrigger className="mt-2 h-12">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="pending">Pending</SelectItem>
                        <SelectItem value="paid">Paid</SelectItem>
                        <SelectItem value="refunded">Refunded</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>
            )}

            {editingType === 'review' && (
              <div className="space-y-6">
                <div className="flex items-center space-x-3">
                  <input
                    type="checkbox"
                    id="isPublic"
                    checked={editingItem.isPublic}
                    onChange={(e) => setEditingItem(prev => ({ ...prev, isPublic: e.target.checked }))}
                    className="w-5 h-5"
                  />
                  <Label htmlFor="isPublic" className="text-base">Make public (show on testimonials page)</Label>
                </div>
              </div>
            )}

            <div className="flex justify-end space-x-4 pt-6 border-t">
              <Button onClick={() => setIsEditDialogOpen(false)} variant="outline" className="px-8 h-12">
                Cancel
              </Button>
              <Button onClick={handleSave} className="px-8 h-12">
                {editingItem.id === 'new' ? 'Add' : 'Save Changes'}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    );
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl">Admin Dashboard</h1>
          <p className="text-gray-600">Comprehensive management system for Tewkesbury Dental Practice</p>
        </div>

        {/* Navigation Tabs */}
        <div className="flex space-x-4 mb-8 border-b overflow-x-auto">
          {[
            { id: 'dashboard', label: 'Dashboard', icon: BarChart3 },
            { id: 'doctors', label: 'Doctors', icon: Stethoscope },
            { id: 'bookings', label: 'Bookings', icon: Calendar },
            { id: 'treatments', label: 'Treatments', icon: CreditCard },
            { id: 'reviews', label: 'Reviews', icon: Star },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center space-x-2 px-4 py-2 border-b-2 transition-colors whitespace-nowrap ${
                activeTab === tab.id
                  ? 'border-teal-600 text-teal-600'
                  : 'border-transparent text-gray-600 hover:text-gray-900'
              }`}
            >
              <tab.icon className="h-4 w-4" />
              <span>{tab.label}</span>
            </button>
          ))}
        </div>

        {/* Content */}
        {activeTab === 'dashboard' && <DashboardStats />}

        {activeTab === 'doctors' && (
          <div>
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl">Manage Doctors</h2>
              <Button onClick={() => handleAdd('doctor')}>
                <Plus className="mr-2 h-4 w-4" />
                Add Doctor
              </Button>
            </div>
            {doctors.length === 0 ? (
              <Card>
                <CardContent className="p-8">
                  <NoDataMessage type="Doctors" />
                </CardContent>
              </Card>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {doctors.map((doctor) => (
                  <Card key={doctor.id}>
                    <CardContent className="p-6">
                      <div className="flex items-start space-x-4">
                        <img 
                          src={doctor.image} 
                          alt={doctor.name}
                          className="w-16 h-16 rounded-full object-cover"
                        />
                        <div className="flex-1">
                          <h3 className="text-lg">{doctor.name}</h3>
                          <p className="text-sm text-gray-600">{doctor.position}</p>
                          <p className="text-sm text-gray-500">{doctor.qualifications}</p>
                          <div className="mt-2">
                            <Badge variant={doctor.isActive ? 'default' : 'secondary'}>
                              {doctor.isActive ? 'Active' : 'Inactive'}
                            </Badge>
                          </div>
                        </div>
                      </div>
                      <div className="flex space-x-2 mt-4">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleEdit(doctor, 'doctor')}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => openDeleteDialog(doctor, 'doctor')}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </div>
        )}

        {activeTab === 'bookings' && (
          <div>
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl">Manage Bookings</h2>
            </div>
            {bookings.length === 0 ? (
              <Card>
                <CardContent className="p-8">
                  <NoDataMessage type="Bookings" />
                </CardContent>
              </Card>
            ) : (
              <div className="space-y-4">
                {bookings.map((booking) => (
                  <Card key={booking.id}>
                    <CardContent className="p-6">
                      <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-4 items-center">
                        <div>
                          <p className="font-medium">{booking.firstName} {booking.lastName}</p>
                          <p className="text-sm text-gray-600">{booking.phone}</p>
                        </div>
                        <div>
                          <p className="text-sm text-gray-600">Treatment</p>
                          <p className="font-medium">{booking.treatmentType}</p>
                        </div>
                        <div>
                          <p className="text-sm text-gray-600">Date & Time</p>
                          <p className="font-medium">{new Date(booking.preferredDate).toLocaleDateString()}</p>
                          <p className="text-sm">{booking.preferredTime}</p>
                        </div>
                        <div>
                          <p className="text-sm text-gray-600">Doctor</p>
                          <p className="font-medium">{booking.doctorAssigned || 'Not assigned'}</p>
                        </div>
                        <div>
                          <Badge 
                            variant={
                              booking.status === 'confirmed' ? 'default' :
                              booking.status === 'pending' ? 'secondary' :
                              booking.status === 'completed' ? 'outline' : 'destructive'
                            }
                          >
                            {booking.status}
                          </Badge>
                        </div>
                        <div className="flex space-x-2">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleEdit(booking, 'booking')}
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => openDeleteDialog(booking, 'booking')}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </div>
        )}

        {activeTab === 'treatments' && (
          <div>
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl">Manage Treatments</h2>
              <Button onClick={() => handleAdd('treatment')}>
                <Plus className="mr-2 h-4 w-4" />
                Add Treatment
              </Button>
            </div>
            {treatments.length === 0 ? (
              <Card>
                <CardContent className="p-8">
                  <NoDataMessage type="Treatments" />
                </CardContent>
              </Card>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {treatments.map((treatment) => (
                  <Card key={treatment.id}>
                    <CardContent className="p-6">
                      <div className="space-y-4">
                        <div>
                          <img 
                            src={treatment.image} 
                            alt={treatment.title}
                            className="w-full h-32 object-cover rounded-lg"
                          />
                        </div>
                        <div>
                          <h3 className="text-lg font-medium">{treatment.title}</h3>
                          <p className="text-sm text-gray-600">{treatment.category}</p>
                          <p className="text-sm text-gray-500">{treatment.duration}</p>
                          <p className="text-lg font-semibold text-teal-600">{treatment.price}</p>
                          <div className="mt-2">
                            <Badge variant={treatment.isActive ? 'default' : 'secondary'}>
                              {treatment.isActive ? 'Active' : 'Inactive'}
                            </Badge>
                          </div>
                        </div>
                        <div className="flex space-x-2">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleEdit(treatment, 'treatment')}
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => openDeleteDialog(treatment, 'treatment')}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </div>
        )}

        {activeTab === 'reviews' && (
          <div>
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl">Manage Reviews</h2>
            </div>
            {reviews.length === 0 ? (
              <Card>
                <CardContent className="p-8">
                  <NoDataMessage type="Reviews" />
                </CardContent>
              </Card>
            ) : (
              <div className="space-y-4">
                {reviews.map((review) => (
                  <Card key={review.id}>
                    <CardContent className="p-6">
                      <div className="space-y-4">
                        <div className="flex justify-between items-start">
                          <div>
                            <h3 className="font-medium">{review.patientName}</h3>
                            <p className="text-sm text-gray-600">{review.treatmentReceived}</p>
                            <div className="flex items-center space-x-1 mt-1">
                              {[...Array(5)].map((_, i) => (
                                <Star 
                                  key={i} 
                                  className={`h-4 w-4 ${i < review.rating ? 'text-yellow-400 fill-current' : 'text-gray-300'}`} 
                                />
                              ))}
                              <span className="text-sm text-gray-600 ml-2">{review.rating}/5</span>
                            </div>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Badge variant={review.isPublic ? 'default' : 'secondary'}>
                              {review.isPublic ? 'Public' : 'Private'}
                            </Badge>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleEdit(review, 'review')}
                            >
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => openDeleteDialog(review, 'review')}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                        <p className="text-gray-700">{review.reviewText}</p>
                        <p className="text-sm text-gray-500">{new Date(review.date).toLocaleDateString()}</p>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Edit Dialog */}
        {renderEditDialog()}

        {/* Delete Confirmation Dialog */}
        <AlertDialog open={deleteDialog.open} onOpenChange={(open) => setDeleteDialog(prev => ({ ...prev, open }))}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Are you sure?</AlertDialogTitle>
              <AlertDialogDescription>
                This action cannot be undone. This will permanently delete the {deleteDialog.type}.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancel</AlertDialogCancel>
              <AlertDialogAction onClick={handleDelete} className="bg-red-600 hover:bg-red-700">
                Delete
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>
    </div>
  );
};

export default AdminDashboard;