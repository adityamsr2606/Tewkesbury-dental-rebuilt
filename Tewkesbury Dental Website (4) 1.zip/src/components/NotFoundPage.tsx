import React from 'react';
import { Link } from 'react-router-dom';
import { Home, ArrowLeft, Search } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent } from './ui/card';

const NotFoundPage = () => {
  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full space-y-8 text-center">
        <div>
          <h1 className="text-9xl text-teal-600 mb-4">404</h1>
          <h2 className="text-3xl mb-4">Page Not Found</h2>
          <p className="text-xl text-gray-600 mb-8">
            Sorry, we couldn't find the page you're looking for. It might have been moved, deleted, or you entered the wrong URL.
          </p>
        </div>

        <Card>
          <CardContent className="p-6 space-y-4">
            <h3 className="text-lg mb-4">What you can do:</h3>
            <div className="space-y-3">
              <Link to="/" className="block">
                <Button className="w-full" size="lg">
                  <Home className="mr-2 h-4 w-4" />
                  Go to Homepage
                </Button>
              </Link>
              
              <Button 
                variant="outline" 
                onClick={() => window.history.back()} 
                className="w-full"
                size="lg"
              >
                <ArrowLeft className="mr-2 h-4 w-4" />
                Go Back
              </Button>

              <Link to="/contact" className="block">
                <Button variant="outline" className="w-full" size="lg">
                  <Search className="mr-2 h-4 w-4" />
                  Contact Us for Help
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>

        <div className="text-sm text-gray-500">
          <p>
            If you believe this is an error, please{' '}
            <Link to="/contact" className="text-teal-600 hover:text-teal-800 underline">
              contact our support team
            </Link>
            .
          </p>
        </div>
      </div>
    </div>
  );
};

export default NotFoundPage;