import * as React from "react";
import { Slot } from "@radix-ui/react-slot@1.1.2";
import { cva, type VariantProps } from "class-variance-authority@0.7.1";

import { cn } from "./utils";

const buttonVariants = cva(
  "inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-lg font-medium transition-all duration-200 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg:not([class*='size-'])]:size-4 shrink-0 [&_svg]:shrink-0 outline-none focus-visible:ring-2 focus-visible:ring-teal-500/20 focus-visible:ring-offset-2 shadow-sm hover:shadow-md active:scale-[0.98]",
  {
    variants: {
      variant: {
        // Primary teal button for main actions (Book Appointment, etc.)
        primary: "bg-teal-600 text-white hover:bg-teal-700 active:bg-teal-800 border border-teal-600 hover:border-teal-700",
        
        // Secondary blue button for important secondary actions
        secondary: "bg-blue-600 text-white hover:bg-blue-700 active:bg-blue-800 border border-blue-600 hover:border-blue-700",
        
        // Default professional button
        default: "bg-gray-900 text-white hover:bg-gray-800 active:bg-gray-900 border border-gray-900 hover:border-gray-800",
        
        // Outline teal for secondary actions
        outline: "border-2 border-teal-600 text-teal-700 bg-white hover:bg-teal-50 hover:text-teal-800 active:bg-teal-100",
        
        // Outline secondary for less important actions
        "outline-secondary": "border-2 border-gray-300 text-gray-700 bg-white hover:bg-gray-50 hover:text-gray-900 hover:border-gray-400 active:bg-gray-100",
        
        // Ghost for subtle actions
        ghost: "text-gray-700 bg-transparent hover:bg-gray-100 hover:text-gray-900 active:bg-gray-200 border border-transparent",
        
        // Success state
        success: "bg-green-600 text-white hover:bg-green-700 active:bg-green-800 border border-green-600 hover:border-green-700",
        
        // Warning state  
        warning: "bg-amber-500 text-white hover:bg-amber-600 active:bg-amber-700 border border-amber-500 hover:border-amber-600",
        
        // Destructive for dangerous actions
        destructive: "bg-red-600 text-white hover:bg-red-700 active:bg-red-800 border border-red-600 hover:border-red-700",
        
        // Link style
        link: "text-teal-600 underline-offset-4 hover:underline hover:text-teal-700 bg-transparent border-none shadow-none hover:shadow-none",
      },
      size: {
        sm: "h-8 px-3 text-sm gap-1.5",
        default: "h-10 px-4 text-sm gap-2",
        lg: "h-12 px-6 text-base gap-2",
        xl: "h-14 px-8 text-lg gap-3",
        icon: "size-10 p-0",
        "icon-sm": "size-8 p-0",
        "icon-lg": "size-12 p-0",
      },
    },
    defaultVariants: {
      variant: "default",
      size: "default",
    },
  },
);

function Button({
  className,
  variant,
  size,
  asChild = false,
  ...props
}: React.ComponentProps<"button"> &
  VariantProps<typeof buttonVariants> & {
    asChild?: boolean;
  }) {
  const Comp = asChild ? Slot : "button";

  return (
    <Comp
      data-slot="button"
      className={cn(buttonVariants({ variant, size, className }))}
      {...props}
    />
  );
}

export { Button, buttonVariants };
