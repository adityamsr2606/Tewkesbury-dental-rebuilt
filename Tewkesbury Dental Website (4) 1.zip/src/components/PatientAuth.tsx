import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { User, Lock, Mail, Eye, EyeOff, UserPlus, Calendar, Phone, MapPin } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Alert, AlertDescription } from './ui/alert';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Textarea } from './ui/textarea';
import { useDataStore } from './data/dataStore';

const PatientAuth = () => {
  const navigate = useNavigate();
  const { addPatient } = useDataStore();
  const [isLoading, setIsLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [errors, setErrors] = useState({});
  
  const [loginData, setLoginData] = useState({
    email: '',
    password: '',
  });

  const [signupData, setSignupData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    dateOfBirth: '',
    address: '',
    emergencyContact: '',
    medicalHistory: '',
    allergies: '',
    currentMedications: '',
    insuranceProvider: '',
    insuranceNumber: '',
    password: '',
    confirmPassword: '',
  });

  const validateLogin = () => {
    const newErrors = {};
    
    if (!loginData.email.trim()) {
      newErrors.email = 'Email is required';
    } else if (!loginData.email.includes('@')) {
      newErrors.email = 'Please enter a valid email address';
    }
    
    if (!loginData.password.trim()) {
      newErrors.password = 'Password is required';
    }
    
    return newErrors;
  };

  const validateSignup = () => {
    const newErrors = {};
    
    if (!signupData.firstName.trim()) {
      newErrors.firstName = 'First name is required';
    }
    
    if (!signupData.lastName.trim()) {
      newErrors.lastName = 'Last name is required';
    }
    
    if (!signupData.email.trim()) {
      newErrors.email = 'Email is required';
    } else if (!signupData.email.includes('@')) {
      newErrors.email = 'Please enter a valid email address';
    }
    
    if (!signupData.phone.trim()) {
      newErrors.phone = 'Phone number is required';
    }
    
    if (!signupData.dateOfBirth.trim()) {
      newErrors.dateOfBirth = 'Date of birth is required';
    }
    
    if (!signupData.address.trim()) {
      newErrors.address = 'Address is required';
    }
    
    if (!signupData.password.trim()) {
      newErrors.password = 'Password is required';
    } else if (signupData.password.length < 6) {
      newErrors.password = 'Password must be at least 6 characters';
    }
    
    if (signupData.password !== signupData.confirmPassword) {
      newErrors.confirmPassword = 'Passwords do not match';
    }
    
    return newErrors;
  };

  const handleLogin = async (e) => {
    e.preventDefault();
    const newErrors = validateLogin();
    
    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    setIsLoading(true);
    setErrors({});

    try {
      // Mock authentication - in real implementation, this would use Supabase Auth
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // Mock patient login
      localStorage.setItem('patientToken', 'mock-patient-token');
      localStorage.setItem('patientUser', JSON.stringify({
        id: 'patient-1',
        email: loginData.email,
        role: 'patient'
      }));
      
      navigate('/patient/dashboard');
    } catch (error) {
      setErrors({ login: 'Login failed. Please try again.' });
    } finally {
      setIsLoading(false);
    }
  };

  const handleSignup = async (e) => {
    e.preventDefault();
    const newErrors = validateSignup();
    
    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    setIsLoading(true);
    setErrors({});

    try {
      // Mock registration
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // Add patient to store
      const newPatient = {
        firstName: signupData.firstName,
        lastName: signupData.lastName,
        email: signupData.email,
        phone: signupData.phone,
        dateOfBirth: signupData.dateOfBirth,
        address: signupData.address,
        emergencyContact: signupData.emergencyContact,
        medicalHistory: signupData.medicalHistory,
        allergies: signupData.allergies,
        currentMedications: signupData.currentMedications,
        insuranceProvider: signupData.insuranceProvider,
        insuranceNumber: signupData.insuranceNumber,
        lastVisit: '',
        nextAppointment: '',
        status: 'active' as const
      };
      
      addPatient(newPatient);
      
      setErrors({ success: 'Registration successful! Please login with your credentials.' });
      
      // Reset form
      setSignupData({
        firstName: '', lastName: '', email: '', phone: '', dateOfBirth: '',
        address: '', emergencyContact: '', medicalHistory: '', allergies: '',
        currentMedications: '', insuranceProvider: '', insuranceNumber: '',
        password: '', confirmPassword: ''
      });
    } catch (error) {
      setErrors({ signup: 'Registration failed. Please try again.' });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-2xl w-full space-y-8">
        <div className="text-center">
          <h2 className="text-3xl">Patient Portal</h2>
          <p className="mt-2 text-gray-600">
            Access your patient account or register as a new patient
          </p>
        </div>

        <Card className="mt-8">
          <CardContent className="p-6">
            <Tabs defaultValue="login" className="w-full">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="login">Patient Login</TabsTrigger>
                <TabsTrigger value="signup">New Patient Registration</TabsTrigger>
              </TabsList>
              
              <TabsContent value="login" className="space-y-4 mt-6">
                <form onSubmit={handleLogin} className="space-y-4">
                  <div>
                    <Label htmlFor="email">Email Address</Label>
                    <div className="relative">
                      <Mail className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                      <Input
                        id="email"
                        type="email"
                        value={loginData.email}
                        onChange={(e) => setLoginData(prev => ({ ...prev, email: e.target.value }))}
                        className={`pl-10 ${errors.email ? 'border-red-500' : ''}`}
                        placeholder="Enter your email"
                      />
                    </div>
                    {errors.email && (
                      <p className="text-red-500 text-sm mt-1">{errors.email}</p>
                    )}
                  </div>

                  <div>
                    <Label htmlFor="password">Password</Label>
                    <div className="relative">
                      <Lock className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                      <Input
                        id="password"
                        type={showPassword ? 'text' : 'password'}
                        value={loginData.password}
                        onChange={(e) => setLoginData(prev => ({ ...prev, password: e.target.value }))}
                        className={`pl-10 pr-10 ${errors.password ? 'border-red-500' : ''}`}
                        placeholder="Enter your password"
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute right-3 top-3 text-gray-400 hover:text-gray-600"
                      >
                        {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                      </button>
                    </div>
                    {errors.password && (
                      <p className="text-red-500 text-sm mt-1">{errors.password}</p>
                    )}
                  </div>

                  {errors.login && (
                    <Alert variant="destructive">
                      <AlertDescription>{errors.login}</AlertDescription>
                    </Alert>
                  )}

                  <Button 
                    type="submit" 
                    className="w-full" 
                    disabled={isLoading}
                  >
                    {isLoading ? 'Signing In...' : 'Sign In'}
                  </Button>
                </form>
              </TabsContent>

              <TabsContent value="signup" className="space-y-4 mt-6">
                <form onSubmit={handleSignup} className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="firstName">First Name *</Label>
                      <Input
                        id="firstName"
                        value={signupData.firstName}
                        onChange={(e) => setSignupData(prev => ({ ...prev, firstName: e.target.value }))}
                        className={errors.firstName ? 'border-red-500' : ''}
                        placeholder="First name"
                      />
                      {errors.firstName && (
                        <p className="text-red-500 text-sm mt-1">{errors.firstName}</p>
                      )}
                    </div>
                    <div>
                      <Label htmlFor="lastName">Last Name *</Label>
                      <Input
                        id="lastName"
                        value={signupData.lastName}
                        onChange={(e) => setSignupData(prev => ({ ...prev, lastName: e.target.value }))}
                        className={errors.lastName ? 'border-red-500' : ''}
                        placeholder="Last name"
                      />
                      {errors.lastName && (
                        <p className="text-red-500 text-sm mt-1">{errors.lastName}</p>
                      )}
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="signupEmail">Email Address *</Label>
                      <div className="relative">
                        <Mail className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                        <Input
                          id="signupEmail"
                          type="email"
                          value={signupData.email}
                          onChange={(e) => setSignupData(prev => ({ ...prev, email: e.target.value }))}
                          className={`pl-10 ${errors.email ? 'border-red-500' : ''}`}
                          placeholder="Enter email address"
                        />
                      </div>
                      {errors.email && (
                        <p className="text-red-500 text-sm mt-1">{errors.email}</p>
                      )}
                    </div>
                    <div>
                      <Label htmlFor="phone">Phone Number *</Label>
                      <div className="relative">
                        <Phone className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                        <Input
                          id="phone"
                          value={signupData.phone}
                          onChange={(e) => setSignupData(prev => ({ ...prev, phone: e.target.value }))}
                          className={`pl-10 ${errors.phone ? 'border-red-500' : ''}`}
                          placeholder="Phone number"
                        />
                      </div>
                      {errors.phone && (
                        <p className="text-red-500 text-sm mt-1">{errors.phone}</p>
                      )}
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="dateOfBirth">Date of Birth *</Label>
                    <div className="relative">
                      <Calendar className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                      <Input
                        id="dateOfBirth"
                        type="date"
                        value={signupData.dateOfBirth}
                        onChange={(e) => setSignupData(prev => ({ ...prev, dateOfBirth: e.target.value }))}
                        className={`pl-10 ${errors.dateOfBirth ? 'border-red-500' : ''}`}
                      />
                    </div>
                    {errors.dateOfBirth && (
                      <p className="text-red-500 text-sm mt-1">{errors.dateOfBirth}</p>
                    )}
                  </div>

                  <div>
                    <Label htmlFor="address">Address *</Label>
                    <div className="relative">
                      <MapPin className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                      <Textarea
                        id="address"
                        value={signupData.address}
                        onChange={(e) => setSignupData(prev => ({ ...prev, address: e.target.value }))}
                        className={`pl-10 ${errors.address ? 'border-red-500' : ''}`}
                        placeholder="Full address"
                        rows={2}
                      />
                    </div>
                    {errors.address && (
                      <p className="text-red-500 text-sm mt-1">{errors.address}</p>
                    )}
                  </div>

                  <div>
                    <Label htmlFor="emergencyContact">Emergency Contact</Label>
                    <Input
                      id="emergencyContact"
                      value={signupData.emergencyContact}
                      onChange={(e) => setSignupData(prev => ({ ...prev, emergencyContact: e.target.value }))}
                      placeholder="Emergency contact name and phone"
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="insuranceProvider">Insurance Provider</Label>
                      <Input
                        id="insuranceProvider"
                        value={signupData.insuranceProvider}
                        onChange={(e) => setSignupData(prev => ({ ...prev, insuranceProvider: e.target.value }))}
                        placeholder="Insurance company"
                      />
                    </div>
                    <div>
                      <Label htmlFor="insuranceNumber">Insurance Number</Label>
                      <Input
                        id="insuranceNumber"
                        value={signupData.insuranceNumber}
                        onChange={(e) => setSignupData(prev => ({ ...prev, insuranceNumber: e.target.value }))}
                        placeholder="Policy number"
                      />
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="medicalHistory">Medical History</Label>
                    <Textarea
                      id="medicalHistory"
                      value={signupData.medicalHistory}
                      onChange={(e) => setSignupData(prev => ({ ...prev, medicalHistory: e.target.value }))}
                      placeholder="Any relevant medical history..."
                      rows={2}
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="allergies">Allergies</Label>
                      <Input
                        id="allergies"
                        value={signupData.allergies}
                        onChange={(e) => setSignupData(prev => ({ ...prev, allergies: e.target.value }))}
                        placeholder="Known allergies"
                      />
                    </div>
                    <div>
                      <Label htmlFor="currentMedications">Current Medications</Label>
                      <Input
                        id="currentMedications"
                        value={signupData.currentMedications}
                        onChange={(e) => setSignupData(prev => ({ ...prev, currentMedications: e.target.value }))}
                        placeholder="Current medications"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="signupPassword">Password *</Label>
                      <div className="relative">
                        <Lock className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                        <Input
                          id="signupPassword"
                          type={showPassword ? 'text' : 'password'}
                          value={signupData.password}
                          onChange={(e) => setSignupData(prev => ({ ...prev, password: e.target.value }))}
                          className={`pl-10 pr-10 ${errors.password ? 'border-red-500' : ''}`}
                          placeholder="Create password"
                        />
                        <button
                          type="button"
                          onClick={() => setShowPassword(!showPassword)}
                          className="absolute right-3 top-3 text-gray-400 hover:text-gray-600"
                        >
                          {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                        </button>
                      </div>
                      {errors.password && (
                        <p className="text-red-500 text-sm mt-1">{errors.password}</p>
                      )}
                    </div>
                    <div>
                      <Label htmlFor="confirmPassword">Confirm Password *</Label>
                      <div className="relative">
                        <Lock className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                        <Input
                          id="confirmPassword"
                          type={showPassword ? 'text' : 'password'}
                          value={signupData.confirmPassword}
                          onChange={(e) => setSignupData(prev => ({ ...prev, confirmPassword: e.target.value }))}
                          className={`pl-10 ${errors.confirmPassword ? 'border-red-500' : ''}`}
                          placeholder="Confirm password"
                        />
                      </div>
                      {errors.confirmPassword && (
                        <p className="text-red-500 text-sm mt-1">{errors.confirmPassword}</p>
                      )}
                    </div>
                  </div>

                  {errors.signup && (
                    <Alert variant="destructive">
                      <AlertDescription>{errors.signup}</AlertDescription>
                    </Alert>
                  )}

                  {errors.success && (
                    <Alert className="border-green-200 bg-green-50">
                      <AlertDescription className="text-green-600">{errors.success}</AlertDescription>
                    </Alert>
                  )}

                  <Button 
                    type="submit" 
                    className="w-full" 
                    disabled={isLoading}
                  >
                    <UserPlus className="mr-2 h-4 w-4" />
                    {isLoading ? 'Creating Account...' : 'Register as Patient'}
                  </Button>
                </form>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>

        <div className="text-center text-sm text-gray-600">
          <p>
            For staff access, please use the{' '}
            <a href="/admin" className="text-teal-600 hover:text-teal-800 underline">
              admin portal
            </a>
            .
          </p>
        </div>
      </div>
    </div>
  );
};

export default PatientAuth;