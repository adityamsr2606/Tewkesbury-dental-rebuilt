import React from 'react';
import { Link } from 'react-router-dom';
import { Clock, Star, ChevronRight, Calendar } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { useDataStore } from './data/dataStore';

const TreatmentsPage = () => {
  const { treatments } = useDataStore();
  
  // Filter only active treatments and group by category
  const activetreatments = treatments.filter(treatment => treatment.isActive);
  const treatmentsByCategory = activetreatments.reduce((acc, treatment) => {
    if (!acc[treatment.category]) {
      acc[treatment.category] = [];
    }
    acc[treatment.category].push(treatment);
    return acc;
  }, {});

  // Scroll to top on page load
  React.useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  const categoryDescriptions = {
    'General Dentistry': 'Comprehensive dental care for maintaining optimal oral health and preventing dental problems.',
    'Cosmetic Dentistry': 'Advanced treatments to enhance the appearance of your smile and boost your confidence.',
    'Restorative Dentistry': 'Repair and restore damaged teeth to their natural function and appearance.',
    'Oral Surgery': 'Specialized surgical procedures performed with precision and care in our modern facility.',
    'Facial Aesthetics': 'Non-surgical cosmetic treatments to enhance your natural beauty and reduce signs of aging.'
  };

  if (activetreatments.length === 0) {
    return (
      <div className="min-h-screen bg-gray-50 py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl mb-4">Our Treatments</h1>
            <p className="text-xl text-gray-600 mb-8">
              We're currently updating our treatment offerings. Please check back soon or contact us for more information.
            </p>
            <Link to="/contact">
              <Button variant="primary" size="lg">Contact Us</Button>
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-r from-blue-600 to-teal-600 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl lg:text-6xl mb-6">Our Dental Treatments</h1>
            <p className="text-xl lg:text-2xl text-blue-100 max-w-3xl mx-auto">
              Comprehensive dental care using the latest techniques and technology 
              to ensure your optimal oral health and beautiful smile.
            </p>
          </div>
        </div>
      </section>

      {/* Treatment Categories */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {Object.entries(treatmentsByCategory).map(([category, categoryTreatments], categoryIndex) => (
            <div key={category} className={categoryIndex > 0 ? 'mt-16' : ''}>
              {/* Category Header */}
              <div className="text-center mb-12">
                <h2 className="text-3xl lg:text-4xl mb-4">{category}</h2>
                <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                  {categoryDescriptions[category] || 'Professional dental treatments tailored to your needs.'}
                </p>
              </div>

              {/* Treatment Cards */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {categoryTreatments.map((treatment) => (
                  <Card key={treatment.id} className="flex flex-col overflow-hidden hover:shadow-lg transition-shadow duration-300 h-full">
                    <div className="relative">
                      <ImageWithFallback
                        src={treatment.image}
                        alt={treatment.title}
                        className="w-full h-48 object-cover"
                      />
                      <div className="absolute top-4 right-4">
                        <Badge className="bg-teal-600 text-white">
                          {treatment.price}
                        </Badge>
                      </div>
                    </div>
                    
                    <CardHeader className="flex-shrink-0">
                      <CardTitle className="text-xl">{treatment.title}</CardTitle>
                      <div className="flex items-center text-sm text-gray-600">
                        <Clock className="h-4 w-4 mr-1" />
                        {treatment.duration}
                      </div>
                    </CardHeader>
                    
                    <CardContent className="flex flex-col flex-1 space-y-4">
                      <p className="text-gray-600">{treatment.description}</p>
                      
                      {treatment.services && treatment.services.length > 0 && (
                        <div className="flex-1">
                          <h4 className="text-sm mb-2">Included:</h4>
                          <ul className="space-y-1">
                            {treatment.services.slice(0, 3).map((service, index) => (
                              <li key={index} className="text-sm text-gray-600 flex items-center">
                                <div className="w-1 h-1 bg-teal-600 rounded-full mr-2"></div>
                                {service}
                              </li>
                            ))}
                            {treatment.services.length > 3 && (
                              <li className="text-sm text-gray-500">
                                +{treatment.services.length - 3} more services
                              </li>
                            )}
                          </ul>
                        </div>
                      )}
                      
                      <div className="mt-auto pt-4 space-y-2">
                        <Link to="/book" className="block">
                          <Button variant="primary" className="w-full">
                            <Calendar className="mr-2 h-4 w-4" />
                            Book Appointment
                          </Button>
                        </Link>
                        <Link to="/fees" className="block">
                          <Button variant="outline-secondary" className="w-full">
                            View Pricing
                          </Button>
                        </Link>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Features Section */}
      <section className="bg-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl lg:text-4xl mb-4">Why Choose Our Treatments?</h2>
            <p className="text-xl text-gray-600">
              Experience the difference of professional dental care with our comprehensive approach.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              {
                icon: <Star className="h-8 w-8 text-yellow-500" />,
                title: 'Expert Care',
                description: 'Experienced dentists with specialized training'
              },
              {
                icon: <Clock className="h-8 w-8 text-blue-500" />,
                title: 'Efficient Service',
                description: 'Minimal waiting times and prompt treatment'
              },
              {
                icon: <Badge className="h-8 w-8 text-green-500" />,
                title: 'Quality Materials',
                description: 'Premium materials for lasting results'
              },
              {
                icon: <ChevronRight className="h-8 w-8 text-teal-500" />,
                title: 'Follow-up Care',
                description: 'Comprehensive aftercare and support'
              }
            ].map((feature, index) => (
              <Card key={index} className="text-center p-6">
                <CardContent className="space-y-4">
                  <div className="flex justify-center">{feature.icon}</div>
                  <h3 className="text-xl">{feature.title}</h3>
                  <p className="text-gray-600">{feature.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>


    </div>
  );
};

export default TreatmentsPage;