import React from 'react';
import { Link } from 'react-router-dom';
import { Award, Users, Clock, Shield, Heart, Star } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { useDataStore } from './data/dataStore';

const AboutPage = () => {
  const { doctors, practiceInfo } = useDataStore();
  
  // Filter only active doctors
  const activeDoctors = doctors.filter(doctor => doctor.isActive);

  const values = [
    {
      icon: <Heart className="h-8 w-8 text-red-500" />,
      title: 'Patient-Centered Care',
      description: 'We put our patients first, ensuring comfort and satisfaction in every treatment.',
    },
    {
      icon: <Shield className="h-8 w-8 text-blue-500" />,
      title: 'Safety & Hygiene',
      description: 'Maintaining the highest standards of infection control and patient safety.',
    },
    {
      icon: <Award className="h-8 w-8 text-yellow-500" />,
      title: 'Excellence',
      description: 'Committed to delivering exceptional dental care using the latest techniques.',
    },
    {
      icon: <Users className="h-8 w-8 text-green-500" />,
      title: 'Professional Team',
      description: 'Our qualified team continuously updates their skills and knowledge.',
    },
  ];

  const statistics = [
    { number: '30+', label: 'Years of Service' },
    { number: '10,000+', label: 'Happy Patients' },
    { number: '15,000+', label: 'Treatments Completed' },
    { number: '4.9/5', label: 'Patient Rating' },
  ];

  return (
    <div className="space-y-16">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-r from-blue-600 to-teal-600 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl lg:text-6xl mb-6">About {practiceInfo.name}</h1>
            <p className="text-xl lg:text-2xl text-blue-100 max-w-3xl mx-auto">
              {practiceInfo.aboutText}
            </p>
          </div>
        </div>
      </section>

      {/* Practice Story */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-6">
            <h2 className="text-3xl lg:text-4xl">Our Story</h2>
            <div className="space-y-4 text-gray-600">
              <p className="text-lg">
                Founded in 1994, {practiceInfo.name} has been serving the local community 
                with comprehensive dental care for over 30 years. What started as a small family 
                practice has grown into a modern, state-of-the-art dental facility while maintaining 
                our core values of personalized care and patient comfort.
              </p>
              <p className="text-lg">
                <strong>Our Mission:</strong> {practiceInfo.mission}
              </p>
              <p className="text-lg">
                <strong>Our Vision:</strong> {practiceInfo.vision}
              </p>
              <p className="text-lg">
                Located in the heart of Tewkesbury, we are proud to be part of this vibrant 
                community. Our patients are not just clients; they are our neighbors, friends, 
                and family members. This connection drives us to provide exceptional care that 
                goes beyond just treating teeth – we care for the whole person.
              </p>
            </div>
          </div>
          <div className="space-y-6">
            <ImageWithFallback
              src="https://images.unsplash.com/photo-1642844819197-5f5f21b89ff8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkZW50YWwlMjBjbGluaWMlMjBtb2Rlcm58ZW58MXx8fHwxNzU2Mjc5MTgyfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
              alt="Modern dental practice interior"
              className="rounded-lg shadow-lg w-full h-80 object-cover"
            />
            <div className="grid grid-cols-2 gap-4">
              {statistics.map((stat, index) => (
                <div key={index} className="text-center p-4 bg-teal-50 rounded-lg">
                  <div className="text-2xl text-teal-600">{stat.number}</div>
                  <div className="text-sm text-gray-600">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Our Values */}
      <section className="bg-gray-50 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl lg:text-4xl mb-4">Our Values</h2>
            <p className="text-xl text-gray-600">
              The principles that guide everything we do at {practiceInfo.name}.
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {values.map((value, index) => (
              <Card key={index} className="text-center p-6 h-full">
                <CardContent className="space-y-4">
                  <div className="flex justify-center">{value.icon}</div>
                  <h3 className="text-xl">{value.title}</h3>
                  <p className="text-gray-600">{value.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Our Team */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl lg:text-4xl mb-4">Meet Our Team</h2>
          <p className="text-xl text-gray-600">
            Our experienced and caring dental professionals are here to help you achieve optimal oral health.
          </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {activeDoctors.map((member, index) => (
            <Card key={member.id} className="overflow-hidden">
              <div className="flex flex-col sm:flex-row">
                <div className="sm:w-1/3">
                  <ImageWithFallback
                    src={member.image}
                    alt={member.name}
                    className="w-full h-48 sm:h-full object-cover"
                  />
                </div>
                <div className="sm:w-2/3 p-6">
                  <CardHeader className="p-0 pb-4">
                    <CardTitle className="text-xl">{member.name}</CardTitle>
                    <p className="text-teal-600">{member.position}</p>
                    <Badge variant="outline" className="w-fit">
                      {member.qualifications}
                    </Badge>
                  </CardHeader>
                  <CardContent className="p-0 space-y-3">
                    <p className="text-gray-600 text-sm">{member.bio}</p>
                    {member.specializations && member.specializations.length > 0 && (
                      <div>
                        <p className="text-sm text-gray-500 mb-2">Specializations:</p>
                        <div className="flex flex-wrap gap-1">
                          {member.specializations.map((spec, idx) => (
                            <Badge key={idx} variant="outline" className="text-xs">
                              {spec}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    )}
                    <div className="text-sm text-gray-500">
                      <p>{member.yearsOfExperience}+ years of experience</p>
                    </div>
                  </CardContent>
                </div>
              </div>
            </Card>
          ))}
        </div>
        
        {activeDoctors.length === 0 && (
          <div className="text-center py-12">
            <p className="text-gray-500">No active doctors to display at the moment.</p>
          </div>
        )}
      </section>

      {/* Facilities & Technology */}
      <section className="bg-gray-50 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1704455306925-1401c3012117?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkZW50YWwlMjB0cmVhdG1lbnQlMjBjaGFpcnxlbnwxfHx8fDE3NTYyODc1OTJ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                alt="Modern dental equipment"
                className="rounded-lg shadow-lg w-full h-80 object-cover"
              />
            </div>
            <div className="space-y-6">
              <h2 className="text-3xl lg:text-4xl">State-of-the-Art Facilities</h2>
              <div className="space-y-4 text-gray-600">
                <p className="text-lg">
                  Our modern practice is equipped with the latest dental technology to ensure 
                  accurate diagnoses and effective treatments. We continuously invest in 
                  advanced equipment to provide our patients with the best possible care.
                </p>
                <ul className="space-y-2 text-lg">
                  <li className="flex items-center">
                    <Star className="h-5 w-5 text-teal-600 mr-2" />
                    Digital X-Ray Systems for reduced radiation exposure
                  </li>
                  <li className="flex items-center">
                    <Star className="h-5 w-5 text-teal-600 mr-2" />
                    Intraoral Cameras for better patient understanding
                  </li>
                  <li className="flex items-center">
                    <Star className="h-5 w-5 text-teal-600 mr-2" />
                    Modern Sterilization Equipment for safety
                  </li>
                  <li className="flex items-center">
                    <Star className="h-5 w-5 text-teal-600 mr-2" />
                    Comfortable Treatment Rooms with entertainment systems
                  </li>
                  <li className="flex items-center">
                    <Star className="h-5 w-5 text-teal-600 mr-2" />
                    Accessible facilities for all patients
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-teal-600 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl lg:text-4xl mb-4">Experience the Difference</h2>
          <p className="text-xl mb-8 text-teal-100">
            Join thousands of satisfied patients who trust {practiceInfo.name} with their oral health.
          </p>
          <Link to="/contact">
            <Button  size="lg" className="bg-black text-teal-600:bg-gray-100">
              Contact Us
            </Button>
          </Link>
        </div>
      </section>
    </div>
  );
};

export default AboutPage;