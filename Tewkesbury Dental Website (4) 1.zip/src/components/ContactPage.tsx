import React, { useState } from 'react';
import { MapPin, Phone, Mail, Clock, Send, CheckCircle } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Alert, AlertDescription } from './ui/alert';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';

const ContactPage = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    subject: '',
    message: '',
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Mock form submission
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    setSubmitted(true);
    setIsSubmitting(false);
    setFormData({ name: '', email: '', phone: '', subject: '', message: '' });
  };

  const practiceInfo = {
    name: 'Tewkesbury Dental Practice',
    address: '123 High Street, Tewkesbury, GL20 5AL',
    phone: '01684 295727',
    emergencyPhone: '01684 295727',
    email: 'info@tewkesburydental.co.uk',
    openingHours: {
      'Monday - Friday': '8:30 AM - 5:30 PM',
      'Saturday': '9:00 AM - 1:00 PM',
      'Sunday': 'Closed',
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-r from-blue-600 to-teal-600 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl lg:text-6xl mb-6">Contact Us</h1>
            <p className="text-xl lg:text-2xl text-blue-100 max-w-3xl mx-auto">
              Get in touch with our friendly team. We're here to help with all 
              your dental care needs and answer any questions you may have.
            </p>
          </div>
        </div>
      </section>

      {/* Contact Information */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Contact Details */}
            <div className="space-y-8">
              <div>
                <h2 className="text-3xl mb-6">Get In Touch</h2>
                <p className="text-xl text-gray-600 mb-8">
                  We'd love to hear from you. Choose the most convenient way to reach us.
                </p>
              </div>

              <div className="space-y-6">
                {/* Phone */}
                <Card className="hover:shadow-md transition-shadow">
                  <CardContent className="p-6">
                    <div className="flex items-start space-x-4">
                      <div className="bg-teal-100 p-3 rounded-lg">
                        <Phone className="h-6 w-6 text-teal-600" />
                      </div>
                      <div className="flex-1">
                        <h3 className="text-lg mb-2">Phone</h3>
                        <div className="space-y-1">
                          <a 
                            href={`tel:${practiceInfo.phone}`}
                            className="text-teal-600 hover:text-teal-800 block text-lg transition-colors"
                          >
                            {practiceInfo.phone}
                          </a>
                          <p className="text-sm text-gray-600">General inquiries and appointments</p>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Emergency Contact */}
                <Card className="hover:shadow-md transition-shadow border-red-200">
                  <CardContent className="p-6">
                    <div className="flex items-start space-x-4">
                      <div className="bg-red-100 p-3 rounded-lg">
                        <Phone className="h-6 w-6 text-red-600" />
                      </div>
                      <div className="flex-1">
                        <h3 className="text-lg mb-2">Emergency Contact</h3>
                        <div className="space-y-1">
                          <a 
                            href={`tel:${practiceInfo.emergencyPhone}`}
                            className="text-red-600 hover:text-red-800 block text-lg transition-colors"
                          >
                            {practiceInfo.emergencyPhone}
                          </a>
                          <p className="text-sm text-gray-600">24/7 emergency dental care</p>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Email */}
                <Card className="hover:shadow-md transition-shadow">
                  <CardContent className="p-6">
                    <div className="flex items-start space-x-4">
                      <div className="bg-blue-100 p-3 rounded-lg">
                        <Mail className="h-6 w-6 text-blue-600" />
                      </div>
                      <div className="flex-1">
                        <h3 className="text-lg mb-2">Email</h3>
                        <div className="space-y-1">
                          <a 
                            href={`mailto:${practiceInfo.email}`}
                            className="text-blue-600 hover:text-blue-800 block text-lg transition-colors"
                          >
                            {practiceInfo.email}
                          </a>
                          <p className="text-sm text-gray-600">Send us your questions</p>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Address */}
                <Card className="hover:shadow-md transition-shadow">
                  <CardContent className="p-6">
                    <div className="flex items-start space-x-4">
                      <div className="bg-green-100 p-3 rounded-lg">
                        <MapPin className="h-6 w-6 text-green-600" />
                      </div>
                      <div className="flex-1">
                        <h3 className="text-lg mb-2">Visit Us</h3>
                        <div className="space-y-1">
                          <p className="text-lg">{practiceInfo.address}</p>
                          <p className="text-sm text-gray-600">Easy parking available</p>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Opening Hours */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Clock className="mr-2 h-5 w-5" />
                    Opening Hours
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {Object.entries(practiceInfo.openingHours).map(([day, hours]) => (
                      <div key={day} className="flex justify-between">
                        <span className="">{day}</span>
                        <span className="text-gray-600">{hours}</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Contact Form */}
            <div>
              <Card>
                <CardHeader>
                  <CardTitle>Send us a Message</CardTitle>
                </CardHeader>
                <CardContent>
                  {submitted ? (
                    <div className="text-center py-8">
                      <CheckCircle className="h-16 w-16 text-green-500 mx-auto mb-4" />
                      <h3 className="text-xl mb-2">Message Sent!</h3>
                      <p className="text-gray-600 mb-4">
                        Thank you for contacting us. We'll get back to you within 24 hours.
                      </p>
                      <Button onClick={() => setSubmitted(false)}>
                        Send Another Message
                      </Button>
                    </div>
                  ) : (
                    <form onSubmit={handleSubmit} className="space-y-6">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="name">Full Name *</Label>
                          <Input
                            id="name"
                            name="name"
                            value={formData.name}
                            onChange={handleInputChange}
                            required
                            placeholder="Your full name"
                          />
                        </div>
                        <div>
                          <Label htmlFor="phone">Phone Number</Label>
                          <Input
                            id="phone"
                            name="phone"
                            type="tel"
                            value={formData.phone}
                            onChange={handleInputChange}
                            placeholder="Your phone number"
                          />
                        </div>
                      </div>

                      <div>
                        <Label htmlFor="email">Email Address *</Label>
                        <Input
                          id="email"
                          name="email"
                          type="email"
                          value={formData.email}
                          onChange={handleInputChange}
                          required
                          placeholder="your.email@example.com"
                        />
                      </div>

                      <div>
                        <Label htmlFor="subject">Subject *</Label>
                        <Select 
                          value={formData.subject} 
                          onValueChange={(value) => setFormData(prev => ({ ...prev, subject: value }))}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Select a subject" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="appointment">Book an Appointment</SelectItem>
                            <SelectItem value="general">General Inquiry</SelectItem>
                            <SelectItem value="emergency">Dental Emergency</SelectItem>
                            <SelectItem value="treatment">Treatment Information</SelectItem>
                            <SelectItem value="insurance">Insurance Questions</SelectItem>
                            <SelectItem value="complaint">Complaint or Feedback</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div>
                        <Label htmlFor="message">Message *</Label>
                        <Textarea
                          id="message"
                          name="message"
                          value={formData.message}
                          onChange={handleInputChange}
                          required
                          placeholder="Please describe how we can help you..."
                          rows={5}
                        />
                      </div>

                      <Alert>
                        <AlertDescription>
                          For dental emergencies, please call us directly at{' '}
                          <a href={`tel:${practiceInfo.emergencyPhone}`} className="text-teal-600 hover:text-teal-800 underline">
                            {practiceInfo.emergencyPhone}
                          </a>{' '}
                          for immediate assistance.
                        </AlertDescription>
                      </Alert>

                      <Button 
                        type="submit" 
                        className="w-full" 
                        disabled={isSubmitting}
                      >
                        {isSubmitting ? (
                          'Sending...'
                        ) : (
                          <>
                            <Send className="mr-2 h-4 w-4" />
                            Send Message
                          </>
                        )}
                      </Button>
                    </form>
                  )}
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default ContactPage;