import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X } from 'lucide-react';
import { Button } from './ui/button';
import { ImageWithFallback } from './figma/ImageWithFallback';

const navItems = [
  { name: 'Home', path: '/' },
  { name: 'About Us', path: '/about' },
  { name: 'Dental Treatments', path: '/treatments' },
  { name: 'Facial Aesthetics', path: '/facial-aesthetics' },
  { name: 'Fees', path: '/fees' },
  { name: 'Testimonials', path: '/testimonials' },
  { name: 'Blog', path: '/blog' },
  { name: 'Promotions', path: '/promotions' },
  { name: 'Contact Us', path: '/contact' },
];

const Navigation = () => {
  const [isOpen, setIsOpen] = useState(false);
  const location = useLocation();

  return (
    <nav className="bg-white shadow-lg sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-20">
          {/* Logo */}
          <Link to="/" className="flex items-center">
            <ImageWithFallback
              src="https://www.tewkesburydental.co.uk/wp-content/themes/tewkesbury/images/tewkesbury-logo.png"
              alt="Tewkesbury Dental Practice"
              className="h-12 w-auto"
            />
          </Link>

          {/* Desktop Navigation - Only show for screens 1133px and above */}
          <div className="hidden min-[1133px]:flex items-center space-x-6 px-[30px] py-[0px] mx-[-30px] my-[0px]">
            {navItems.map((item) => (
              <Link
                key={item.path}
                to={item.path}
                className={`transition-colors duration-200 hover:text-teal-600 ${
                  location.pathname === item.path ? 'text-teal-600' : 'text-gray-700'
                }`}
              >
                {item.name}
              </Link>
            ))}
            <Link to="/book">
              <Button variant="primary" size="default">
                Book Appointment
              </Button>
            </Link>
          </div>

          {/* Mobile menu button - Show for screens up to 1132px */}
          <div className="max-[1132px]:block hidden">
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="text-gray-700 hover:text-teal-600"
            >
              {isOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>

        {/* Mobile Navigation - Show for screens up to 1132px */}
        {isOpen && (
          <div className="max-[1132px]:block hidden bg-white border-t border-gray-200">
            <div className="px-2 pt-2 pb-3 space-y-1">
              {navItems.map((item) => (
                <Link
                  key={item.path}
                  to={item.path}
                  className={`block px-3 py-2 rounded-md transition-colors duration-200 ${
                    location.pathname === item.path
                      ? 'bg-teal-50 text-teal-600'
                      : 'text-gray-700 hover:bg-gray-50'
                  }`}
                  onClick={() => setIsOpen(false)}
                >
                  {item.name}
                </Link>
              ))}
              <Link
                to="/book"
                className="block px-3 py-2"
                onClick={() => setIsOpen(false)}
              >
                <Button variant="primary" size="default" className="w-full">
                  Book Appointment
                </Button>
              </Link>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
};

export default Navigation;