import React from 'react';
import { Routes, Route, BrowserRouter as Router, useLocation } from 'react-router-dom';
import Navigation from './components/Navigation';
import Footer from './components/Footer';

// Import components
import HomePage from './components/HomePage';
import AboutPage from './components/AboutPage';
import TreatmentsPage from './components/TreatmentsPage';
import FacialAestheticsPage from './components/FacialAestheticsPage';
import FeesPage from './components/FeesPage';
import TestimonialsPage from './components/TestimonialsPage';
import BlogPage from './components/BlogPage';
import PromotionsPage from './components/PromotionsPage';
import ContactPage from './components/ContactPage';
import AppointmentPage from './components/AppointmentPage';
import BookingFlow from './components/BookingFlow';
import AdminDashboard from './components/AdminDashboard';
import AdminAuth from './components/AdminAuth';

// ScrollToTop component to handle scrolling on route changes
const ScrollToTop = () => {
  const { pathname } = useLocation();

  React.useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);

  return null;
};

// Component to scroll to top on initial page load
const ScrollToTopOnMount = () => {
  React.useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return null;
};

const App = () => {
  return (
    <Router>
      <div className="min-h-screen bg-gray-50">
        <ScrollToTopOnMount />
        <ScrollToTop />
        <Navigation />
        <main>
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/about" element={<AboutPage />} />
            <Route path="/treatments" element={<TreatmentsPage />} />
            <Route path="/facial-aesthetics" element={<FacialAestheticsPage />} />
            <Route path="/fees" element={<FeesPage />} />
            <Route path="/testimonials" element={<TestimonialsPage />} />
            <Route path="/blog" element={<BlogPage />} />
            <Route path="/promotions" element={<PromotionsPage />} />
            <Route path="/contact" element={<ContactPage />} />
            <Route path="/appointment" element={<AppointmentPage />} />
            <Route path="/book" element={<BookingFlow />} />
            <Route path="/admin" element={<AdminAuth />} />
            <Route path="/admin/dashboard" element={<AdminDashboard />} />
          </Routes>
        </main>
        <Footer />
      </div>
    </Router>
  );
};

export default App;